﻿namespace DeTai
{
    partial class UC_ThietBi
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UC_ThietBi));
            this.labelControl2 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.txtName = new DevExpress.XtraEditors.TextEdit();
            this.labelControl3 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl4 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl5 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl6 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl7 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl8 = new DevExpress.XtraEditors.LabelControl();
            this.txtQuyCach = new DevExpress.XtraEditors.TextEdit();
            this.txtSoLuong = new DevExpress.XtraEditors.TextEdit();
            this.txtBaoHanh = new DevExpress.XtraEditors.TextEdit();
            this.txtGiaNhap = new DevExpress.XtraEditors.TextEdit();
            this.txtDonGia = new DevExpress.XtraEditors.TextEdit();
            this.txtMin = new DevExpress.XtraEditors.TextEdit();
            this.txtDonVi = new DevExpress.XtraEditors.TextEdit();
            this.labelControl16 = new DevExpress.XtraEditors.LabelControl();
            this.txtMaTB = new DevExpress.XtraEditors.TextEdit();
            this.labelControl9 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl10 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl11 = new DevExpress.XtraEditors.LabelControl();
            this.nhaSanXuatBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.loaiThietBiBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.btnCheckMaNhom = new DevExpress.XtraEditors.SimpleButton();
            this.lookNSX = new DevExpress.XtraEditors.LookUpEdit();
            this.lookLoaiTB = new DevExpress.XtraEditors.LookUpEdit();
            ((System.ComponentModel.ISupportInitialize)(this.txtName.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtQuyCach.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSoLuong.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtBaoHanh.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtGiaNhap.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDonGia.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMin.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDonVi.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMaTB.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nhaSanXuatBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.loaiThietBiBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookNSX.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookLoaiTB.Properties)).BeginInit();
            this.SuspendLayout();
            // 
            // labelControl2
            // 
            this.labelControl2.Appearance.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl2.Location = new System.Drawing.Point(63, 169);
            this.labelControl2.Name = "labelControl2";
            this.labelControl2.Size = new System.Drawing.Size(78, 20);
            this.labelControl2.TabIndex = 3;
            this.labelControl2.Text = "Tên thiết bị";
            // 
            // labelControl1
            // 
            this.labelControl1.Appearance.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl1.Appearance.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.labelControl1.Location = new System.Drawing.Point(63, 59);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(196, 29);
            this.labelControl1.TabIndex = 2;
            this.labelControl1.Text = "Thông tin thiết bị";
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(201, 163);
            this.txtName.Name = "txtName";
            this.txtName.Properties.Appearance.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtName.Properties.Appearance.Options.UseFont = true;
            this.txtName.Size = new System.Drawing.Size(211, 26);
            this.txtName.TabIndex = 1;
            this.txtName.Click += new System.EventHandler(this.texBox_Click);
            // 
            // labelControl3
            // 
            this.labelControl3.Appearance.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl3.Location = new System.Drawing.Point(63, 218);
            this.labelControl3.Name = "labelControl3";
            this.labelControl3.Size = new System.Drawing.Size(66, 20);
            this.labelControl3.TabIndex = 28;
            this.labelControl3.Text = "Quy cách";
            // 
            // labelControl4
            // 
            this.labelControl4.Appearance.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl4.Location = new System.Drawing.Point(523, 125);
            this.labelControl4.Name = "labelControl4";
            this.labelControl4.Size = new System.Drawing.Size(63, 20);
            this.labelControl4.TabIndex = 29;
            this.labelControl4.Text = "Số lượng";
            // 
            // labelControl5
            // 
            this.labelControl5.Appearance.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl5.Location = new System.Drawing.Point(523, 169);
            this.labelControl5.Name = "labelControl5";
            this.labelControl5.Size = new System.Drawing.Size(117, 20);
            this.labelControl5.TabIndex = 30;
            this.labelControl5.Text = "Bảo hành (ngày)";
            // 
            // labelControl6
            // 
            this.labelControl6.Appearance.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl6.Location = new System.Drawing.Point(63, 369);
            this.labelControl6.Name = "labelControl6";
            this.labelControl6.Size = new System.Drawing.Size(55, 20);
            this.labelControl6.TabIndex = 31;
            this.labelControl6.Text = "Đơn giá";
            // 
            // labelControl7
            // 
            this.labelControl7.Appearance.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl7.Location = new System.Drawing.Point(63, 324);
            this.labelControl7.Name = "labelControl7";
            this.labelControl7.Size = new System.Drawing.Size(65, 20);
            this.labelControl7.TabIndex = 32;
            this.labelControl7.Text = "Giá nhập";
            // 
            // labelControl8
            // 
            this.labelControl8.Appearance.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl8.Location = new System.Drawing.Point(63, 416);
            this.labelControl8.Name = "labelControl8";
            this.labelControl8.Size = new System.Drawing.Size(123, 20);
            this.labelControl8.TabIndex = 33;
            this.labelControl8.Text = "Số lượng tối thiểu";
            // 
            // txtQuyCach
            // 
            this.txtQuyCach.Location = new System.Drawing.Point(201, 212);
            this.txtQuyCach.Name = "txtQuyCach";
            this.txtQuyCach.Properties.Appearance.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQuyCach.Properties.Appearance.Options.UseFont = true;
            this.txtQuyCach.Size = new System.Drawing.Size(211, 26);
            this.txtQuyCach.TabIndex = 2;
            this.txtQuyCach.Click += new System.EventHandler(this.texBox_Click);
            // 
            // txtSoLuong
            // 
            this.txtSoLuong.Location = new System.Drawing.Point(661, 119);
            this.txtSoLuong.Name = "txtSoLuong";
            this.txtSoLuong.Properties.Appearance.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSoLuong.Properties.Appearance.Options.UseFont = true;
            this.txtSoLuong.Properties.Mask.EditMask = "n0";
            this.txtSoLuong.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtSoLuong.Size = new System.Drawing.Size(211, 26);
            this.txtSoLuong.TabIndex = 3;
            this.txtSoLuong.Click += new System.EventHandler(this.texBox_Click);
            // 
            // txtBaoHanh
            // 
            this.txtBaoHanh.Location = new System.Drawing.Point(661, 163);
            this.txtBaoHanh.Name = "txtBaoHanh";
            this.txtBaoHanh.Properties.Appearance.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBaoHanh.Properties.Appearance.Options.UseFont = true;
            this.txtBaoHanh.Properties.Mask.EditMask = "n0";
            this.txtBaoHanh.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtBaoHanh.Size = new System.Drawing.Size(211, 26);
            this.txtBaoHanh.TabIndex = 4;
            this.txtBaoHanh.Click += new System.EventHandler(this.texBox_Click);
            // 
            // txtGiaNhap
            // 
            this.txtGiaNhap.Location = new System.Drawing.Point(201, 318);
            this.txtGiaNhap.Name = "txtGiaNhap";
            this.txtGiaNhap.Properties.Appearance.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGiaNhap.Properties.Appearance.Options.UseFont = true;
            this.txtGiaNhap.Properties.Mask.EditMask = "n";
            this.txtGiaNhap.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtGiaNhap.Size = new System.Drawing.Size(211, 26);
            this.txtGiaNhap.TabIndex = 6;
            this.txtGiaNhap.Click += new System.EventHandler(this.texBox_Click);
            // 
            // txtDonGia
            // 
            this.txtDonGia.Location = new System.Drawing.Point(201, 363);
            this.txtDonGia.Name = "txtDonGia";
            this.txtDonGia.Properties.Appearance.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDonGia.Properties.Appearance.Options.UseFont = true;
            this.txtDonGia.Properties.Mask.EditMask = "n";
            this.txtDonGia.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtDonGia.Size = new System.Drawing.Size(211, 26);
            this.txtDonGia.TabIndex = 7;
            this.txtDonGia.Click += new System.EventHandler(this.texBox_Click);
            // 
            // txtMin
            // 
            this.txtMin.Location = new System.Drawing.Point(201, 410);
            this.txtMin.Name = "txtMin";
            this.txtMin.Properties.Appearance.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMin.Properties.Appearance.Options.UseFont = true;
            this.txtMin.Properties.Mask.EditMask = "n0";
            this.txtMin.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtMin.Size = new System.Drawing.Size(211, 26);
            this.txtMin.TabIndex = 8;
            this.txtMin.Click += new System.EventHandler(this.texBox_Click);
            // 
            // txtDonVi
            // 
            this.txtDonVi.Location = new System.Drawing.Point(661, 212);
            this.txtDonVi.Name = "txtDonVi";
            this.txtDonVi.Properties.Appearance.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDonVi.Properties.Appearance.Options.UseFont = true;
            this.txtDonVi.Size = new System.Drawing.Size(211, 26);
            this.txtDonVi.TabIndex = 5;
            this.txtDonVi.Click += new System.EventHandler(this.texBox_Click);
            // 
            // labelControl16
            // 
            this.labelControl16.Appearance.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl16.Location = new System.Drawing.Point(523, 218);
            this.labelControl16.Name = "labelControl16";
            this.labelControl16.Size = new System.Drawing.Size(44, 20);
            this.labelControl16.TabIndex = 53;
            this.labelControl16.Text = "Đơn vị";
            // 
            // txtMaTB
            // 
            this.txtMaTB.Location = new System.Drawing.Point(201, 117);
            this.txtMaTB.Name = "txtMaTB";
            this.txtMaTB.Properties.Appearance.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMaTB.Properties.Appearance.Options.UseFont = true;
            this.txtMaTB.Size = new System.Drawing.Size(211, 26);
            this.txtMaTB.TabIndex = 0;
            this.txtMaTB.Click += new System.EventHandler(this.texBox_Click);
            // 
            // labelControl9
            // 
            this.labelControl9.Appearance.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl9.Location = new System.Drawing.Point(63, 123);
            this.labelControl9.Name = "labelControl9";
            this.labelControl9.Size = new System.Drawing.Size(73, 20);
            this.labelControl9.TabIndex = 55;
            this.labelControl9.Text = "Mã thiết bị";
            // 
            // labelControl10
            // 
            this.labelControl10.Appearance.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl10.Location = new System.Drawing.Point(523, 321);
            this.labelControl10.Name = "labelControl10";
            this.labelControl10.Size = new System.Drawing.Size(93, 20);
            this.labelControl10.TabIndex = 57;
            this.labelControl10.Text = "Nhà sản xuất";
            // 
            // labelControl11
            // 
            this.labelControl11.Appearance.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl11.Location = new System.Drawing.Point(523, 366);
            this.labelControl11.Name = "labelControl11";
            this.labelControl11.Size = new System.Drawing.Size(81, 20);
            this.labelControl11.TabIndex = 58;
            this.labelControl11.Text = "Loại thiết bị";
            // 
            // nhaSanXuatBindingSource
            // 
            this.nhaSanXuatBindingSource.DataSource = typeof(DeTai.NhaSanXuat);
            // 
            // loaiThietBiBindingSource
            // 
            this.loaiThietBiBindingSource.DataSource = typeof(DeTai.LoaiThietBi);
            // 
            // btnCheckMaNhom
            // 
            this.btnCheckMaNhom.Image = ((System.Drawing.Image)(resources.GetObject("btnCheckMaNhom.Image")));
            this.btnCheckMaNhom.Location = new System.Drawing.Point(418, 118);
            this.btnCheckMaNhom.Name = "btnCheckMaNhom";
            this.btnCheckMaNhom.Size = new System.Drawing.Size(25, 25);
            this.btnCheckMaNhom.TabIndex = 59;
            this.btnCheckMaNhom.ToolTip = "Kiểm tra mã hợp lệ";
            this.btnCheckMaNhom.Click += new System.EventHandler(this.btnCheckMaNhom_Click);
            // 
            // lookNSX
            // 
            this.lookNSX.Location = new System.Drawing.Point(661, 315);
            this.lookNSX.Name = "lookNSX";
            this.lookNSX.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lookNSX.Properties.Appearance.Options.UseFont = true;
            this.lookNSX.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.lookNSX.Properties.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("MaNSX", "Mã NSX", 77, DevExpress.Utils.FormatType.None, "", true, DevExpress.Utils.HorzAlignment.Near),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("TenNSX", "Tên NSX", 71, DevExpress.Utils.FormatType.None, "", true, DevExpress.Utils.HorzAlignment.Near)});
            this.lookNSX.Properties.DataSource = this.nhaSanXuatBindingSource;
            this.lookNSX.Properties.DisplayMember = "TenNSX";
            this.lookNSX.Properties.ValueMember = "MaNSX";
            this.lookNSX.Size = new System.Drawing.Size(211, 26);
            this.lookNSX.TabIndex = 9;
            this.lookNSX.Click += new System.EventHandler(this.texBox_Click);
            // 
            // lookLoaiTB
            // 
            this.lookLoaiTB.Location = new System.Drawing.Point(661, 360);
            this.lookLoaiTB.Name = "lookLoaiTB";
            this.lookLoaiTB.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lookLoaiTB.Properties.Appearance.Options.UseFont = true;
            this.lookLoaiTB.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.lookLoaiTB.Properties.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("MaLoaiTB", "Mã loại thiết bị", 101, DevExpress.Utils.FormatType.None, "", true, DevExpress.Utils.HorzAlignment.Near),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("TenLoaiTB", "Tên", 95, DevExpress.Utils.FormatType.None, "", true, DevExpress.Utils.HorzAlignment.Near)});
            this.lookLoaiTB.Properties.DataSource = this.loaiThietBiBindingSource;
            this.lookLoaiTB.Properties.DisplayMember = "TenLoaiTB";
            this.lookLoaiTB.Properties.ValueMember = "MaLoaiTB";
            this.lookLoaiTB.Size = new System.Drawing.Size(211, 26);
            this.lookLoaiTB.TabIndex = 10;
            this.lookLoaiTB.Click += new System.EventHandler(this.texBox_Click);
            // 
            // UC_ThietBi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.btnCheckMaNhom);
            this.Controls.Add(this.labelControl11);
            this.Controls.Add(this.labelControl10);
            this.Controls.Add(this.txtMaTB);
            this.Controls.Add(this.labelControl9);
            this.Controls.Add(this.txtDonVi);
            this.Controls.Add(this.labelControl16);
            this.Controls.Add(this.txtMin);
            this.Controls.Add(this.txtDonGia);
            this.Controls.Add(this.txtGiaNhap);
            this.Controls.Add(this.txtBaoHanh);
            this.Controls.Add(this.txtSoLuong);
            this.Controls.Add(this.txtQuyCach);
            this.Controls.Add(this.labelControl8);
            this.Controls.Add(this.labelControl7);
            this.Controls.Add(this.labelControl6);
            this.Controls.Add(this.labelControl5);
            this.Controls.Add(this.labelControl4);
            this.Controls.Add(this.labelControl3);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.labelControl2);
            this.Controls.Add(this.labelControl1);
            this.Controls.Add(this.lookNSX);
            this.Controls.Add(this.lookLoaiTB);
            this.Name = "UC_ThietBi";
            this.Size = new System.Drawing.Size(1000, 640);
            this.Load += new System.EventHandler(this.UC_ThietBi_Load);
            ((System.ComponentModel.ISupportInitialize)(this.txtName.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtQuyCach.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSoLuong.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtBaoHanh.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtGiaNhap.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDonGia.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMin.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDonVi.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMaTB.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nhaSanXuatBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.loaiThietBiBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookNSX.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookLoaiTB.Properties)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DevExpress.XtraEditors.LabelControl labelControl2;
        private DevExpress.XtraEditors.LabelControl labelControl1;
        private DevExpress.XtraEditors.TextEdit txtName;
        private DevExpress.XtraEditors.LabelControl labelControl3;
        private DevExpress.XtraEditors.LabelControl labelControl4;
        private DevExpress.XtraEditors.LabelControl labelControl5;
        private DevExpress.XtraEditors.LabelControl labelControl6;
        private DevExpress.XtraEditors.LabelControl labelControl7;
        private DevExpress.XtraEditors.LabelControl labelControl8;
        private DevExpress.XtraEditors.TextEdit txtQuyCach;
        private DevExpress.XtraEditors.TextEdit txtSoLuong;
        private DevExpress.XtraEditors.TextEdit txtBaoHanh;
        private DevExpress.XtraEditors.TextEdit txtGiaNhap;
        private DevExpress.XtraEditors.TextEdit txtDonGia;
        private DevExpress.XtraEditors.TextEdit txtMin;
        private DevExpress.XtraEditors.TextEdit txtDonVi;
        private DevExpress.XtraEditors.LabelControl labelControl16;
        private DevExpress.XtraEditors.TextEdit txtMaTB;
        private DevExpress.XtraEditors.LabelControl labelControl9;
        private DevExpress.XtraEditors.LabelControl labelControl10;
        private DevExpress.XtraEditors.LabelControl labelControl11;
        private DevExpress.XtraEditors.SimpleButton btnCheckMaNhom;
        private System.Windows.Forms.BindingSource nhaSanXuatBindingSource;
        private System.Windows.Forms.BindingSource loaiThietBiBindingSource;
        private DevExpress.XtraEditors.LookUpEdit lookNSX;
        private DevExpress.XtraEditors.LookUpEdit lookLoaiTB;
    }
}
