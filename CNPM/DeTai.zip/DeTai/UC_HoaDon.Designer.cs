﻿namespace DeTai
{
    partial class UC_HoaDon
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl2 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl3 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl4 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl5 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl6 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl7 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl8 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl9 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl10 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl11 = new DevExpress.XtraEditors.LabelControl();
            this.txtFullName = new DevExpress.XtraEditors.TextEdit();
            this.txtAddress = new DevExpress.XtraEditors.TextEdit();
            this.txtPhoneNum = new DevExpress.XtraEditors.TextEdit();
            this.txtPlate = new DevExpress.XtraEditors.TextEdit();
            this.txtColor = new DevExpress.XtraEditors.TextEdit();
            this.dtDateCreate = new DevExpress.XtraEditors.DateEdit();
            this.ckbFinish = new DevExpress.XtraEditors.CheckEdit();
            this.labelControl12 = new DevExpress.XtraEditors.LabelControl();
            this.lblLookKhachHang = new DevExpress.XtraEditors.LabelControl();
            this.lblLookXe = new DevExpress.XtraEditors.LabelControl();
            this.cklstCongViec = new DevExpress.XtraEditors.CheckedListBoxControl();
            this.lookLoaiXe = new DevExpress.XtraEditors.LookUpEdit();
            this.lblClearKH = new DevExpress.XtraEditors.LabelControl();
            this.lblClearXe = new DevExpress.XtraEditors.LabelControl();
            this.labelControl13 = new DevExpress.XtraEditors.LabelControl();
            this.txtNotes = new DevExpress.XtraEditors.MemoEdit();
            this.lblTitle = new DevExpress.XtraEditors.LabelControl();
            this.labelControl14 = new DevExpress.XtraEditors.LabelControl();
            this.txtTamThu = new DevExpress.XtraEditors.TextEdit();
            ((System.ComponentModel.ISupportInitialize)(this.txtFullName.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtAddress.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPhoneNum.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPlate.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtColor.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtDateCreate.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtDateCreate.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ckbFinish.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cklstCongViec)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookLoaiXe.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtNotes.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTamThu.Properties)).BeginInit();
            this.SuspendLayout();
            // 
            // labelControl1
            // 
            this.labelControl1.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl1.Location = new System.Drawing.Point(77, 87);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(176, 19);
            this.labelControl1.TabIndex = 0;
            this.labelControl1.Text = "Thông tin khách hàng";
            // 
            // labelControl2
            // 
            this.labelControl2.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl2.Location = new System.Drawing.Point(77, 116);
            this.labelControl2.Name = "labelControl2";
            this.labelControl2.Size = new System.Drawing.Size(113, 19);
            this.labelControl2.TabIndex = 1;
            this.labelControl2.Text = "Tên khách hàng";
            // 
            // labelControl3
            // 
            this.labelControl3.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl3.Location = new System.Drawing.Point(77, 161);
            this.labelControl3.Name = "labelControl3";
            this.labelControl3.Size = new System.Drawing.Size(48, 19);
            this.labelControl3.TabIndex = 2;
            this.labelControl3.Text = "Địa chỉ";
            // 
            // labelControl4
            // 
            this.labelControl4.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl4.Location = new System.Drawing.Point(77, 205);
            this.labelControl4.Name = "labelControl4";
            this.labelControl4.Size = new System.Drawing.Size(93, 19);
            this.labelControl4.TabIndex = 3;
            this.labelControl4.Text = "Số điện thoại";
            // 
            // labelControl5
            // 
            this.labelControl5.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl5.Location = new System.Drawing.Point(596, 83);
            this.labelControl5.Name = "labelControl5";
            this.labelControl5.Size = new System.Drawing.Size(103, 19);
            this.labelControl5.TabIndex = 4;
            this.labelControl5.Text = "Thông tin xe";
            // 
            // labelControl6
            // 
            this.labelControl6.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl6.Location = new System.Drawing.Point(596, 112);
            this.labelControl6.Name = "labelControl6";
            this.labelControl6.Size = new System.Drawing.Size(39, 19);
            this.labelControl6.TabIndex = 5;
            this.labelControl6.Text = "Số xe";
            // 
            // labelControl7
            // 
            this.labelControl7.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl7.Location = new System.Drawing.Point(596, 155);
            this.labelControl7.Name = "labelControl7";
            this.labelControl7.Size = new System.Drawing.Size(50, 19);
            this.labelControl7.TabIndex = 6;
            this.labelControl7.Text = "Loại xe";
            // 
            // labelControl8
            // 
            this.labelControl8.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl8.Location = new System.Drawing.Point(596, 202);
            this.labelControl8.Name = "labelControl8";
            this.labelControl8.Size = new System.Drawing.Size(50, 19);
            this.labelControl8.TabIndex = 7;
            this.labelControl8.Text = "Màu xe";
            // 
            // labelControl9
            // 
            this.labelControl9.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl9.Location = new System.Drawing.Point(77, 260);
            this.labelControl9.Name = "labelControl9";
            this.labelControl9.Size = new System.Drawing.Size(148, 19);
            this.labelControl9.TabIndex = 8;
            this.labelControl9.Text = "Thông tin hóa đơn";
            // 
            // labelControl10
            // 
            this.labelControl10.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl10.Location = new System.Drawing.Point(77, 289);
            this.labelControl10.Name = "labelControl10";
            this.labelControl10.Size = new System.Drawing.Size(111, 19);
            this.labelControl10.TabIndex = 9;
            this.labelControl10.Text = "Ngày làm phiếu";
            // 
            // labelControl11
            // 
            this.labelControl11.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl11.Location = new System.Drawing.Point(77, 330);
            this.labelControl11.Name = "labelControl11";
            this.labelControl11.Size = new System.Drawing.Size(74, 19);
            this.labelControl11.TabIndex = 10;
            this.labelControl11.Text = "Tình trạng";
            // 
            // txtFullName
            // 
            this.txtFullName.Location = new System.Drawing.Point(212, 109);
            this.txtFullName.Name = "txtFullName";
            this.txtFullName.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFullName.Properties.Appearance.Options.UseFont = true;
            this.txtFullName.Size = new System.Drawing.Size(210, 26);
            this.txtFullName.TabIndex = 0;
            this.txtFullName.Click += new System.EventHandler(this.texbox_Click);
            // 
            // txtAddress
            // 
            this.txtAddress.Location = new System.Drawing.Point(212, 154);
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAddress.Properties.Appearance.Options.UseFont = true;
            this.txtAddress.Size = new System.Drawing.Size(210, 26);
            this.txtAddress.TabIndex = 1;
            this.txtAddress.Click += new System.EventHandler(this.texbox_Click);
            // 
            // txtPhoneNum
            // 
            this.txtPhoneNum.Location = new System.Drawing.Point(212, 198);
            this.txtPhoneNum.Name = "txtPhoneNum";
            this.txtPhoneNum.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPhoneNum.Properties.Appearance.Options.UseFont = true;
            this.txtPhoneNum.Size = new System.Drawing.Size(210, 26);
            this.txtPhoneNum.TabIndex = 2;
            this.txtPhoneNum.ToolTip = "Định dạng 08-123-1234 hoặc 061-123-1234";
            this.txtPhoneNum.Click += new System.EventHandler(this.texbox_Click);
            // 
            // txtPlate
            // 
            this.txtPlate.Location = new System.Drawing.Point(673, 108);
            this.txtPlate.Name = "txtPlate";
            this.txtPlate.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPlate.Properties.Appearance.Options.UseFont = true;
            this.txtPlate.Size = new System.Drawing.Size(210, 26);
            this.txtPlate.TabIndex = 3;
            this.txtPlate.ToolTip = "Định dạng: 60y8-1234 hoặc 60y8-12345";
            this.txtPlate.Click += new System.EventHandler(this.texbox_Click);
            // 
            // txtColor
            // 
            this.txtColor.Location = new System.Drawing.Point(673, 198);
            this.txtColor.Name = "txtColor";
            this.txtColor.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtColor.Properties.Appearance.Options.UseFont = true;
            this.txtColor.Size = new System.Drawing.Size(210, 26);
            this.txtColor.TabIndex = 5;
            this.txtColor.Click += new System.EventHandler(this.texbox_Click);
            // 
            // dtDateCreate
            // 
            this.dtDateCreate.EditValue = null;
            this.dtDateCreate.Location = new System.Drawing.Point(212, 285);
            this.dtDateCreate.Name = "dtDateCreate";
            this.dtDateCreate.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtDateCreate.Properties.Appearance.Options.UseFont = true;
            this.dtDateCreate.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dtDateCreate.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dtDateCreate.Properties.CalendarTimeProperties.CloseUpKey = new DevExpress.Utils.KeyShortcut(System.Windows.Forms.Keys.F4);
            this.dtDateCreate.Properties.CalendarTimeProperties.PopupBorderStyle = DevExpress.XtraEditors.Controls.PopupBorderStyles.Default;
            this.dtDateCreate.Size = new System.Drawing.Size(210, 26);
            this.dtDateCreate.TabIndex = 6;
            this.dtDateCreate.Click += new System.EventHandler(this.texbox_Click);
            // 
            // ckbFinish
            // 
            this.ckbFinish.Location = new System.Drawing.Point(210, 325);
            this.ckbFinish.Name = "ckbFinish";
            this.ckbFinish.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ckbFinish.Properties.Appearance.Options.UseFont = true;
            this.ckbFinish.Properties.Caption = "Đã sửa xong";
            this.ckbFinish.Size = new System.Drawing.Size(126, 24);
            this.ckbFinish.TabIndex = 7;
            // 
            // labelControl12
            // 
            this.labelControl12.Appearance.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl12.Location = new System.Drawing.Point(596, 255);
            this.labelControl12.Name = "labelControl12";
            this.labelControl12.Size = new System.Drawing.Size(166, 20);
            this.labelControl12.TabIndex = 19;
            this.labelControl12.Text = "Danh sách công việc";
            // 
            // lblLookKhachHang
            // 
            this.lblLookKhachHang.Appearance.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLookKhachHang.Appearance.ForeColor = System.Drawing.Color.Blue;
            this.lblLookKhachHang.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblLookKhachHang.Location = new System.Drawing.Point(268, 88);
            this.lblLookKhachHang.Name = "lblLookKhachHang";
            this.lblLookKhachHang.Size = new System.Drawing.Size(48, 18);
            this.lblLookKhachHang.TabIndex = 25;
            this.lblLookKhachHang.Text = "Lookup";
            this.lblLookKhachHang.ToolTip = "Nhập thông khách hàngsẵn có";
            this.lblLookKhachHang.Click += new System.EventHandler(this.lblLookKhachHang_Click);
            // 
            // lblLookXe
            // 
            this.lblLookXe.Appearance.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLookXe.Appearance.ForeColor = System.Drawing.Color.Blue;
            this.lblLookXe.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblLookXe.Location = new System.Drawing.Point(714, 84);
            this.lblLookXe.Name = "lblLookXe";
            this.lblLookXe.Size = new System.Drawing.Size(48, 18);
            this.lblLookXe.TabIndex = 26;
            this.lblLookXe.Text = "Lookup";
            this.lblLookXe.ToolTip = "Nhập thông tin xe đã có";
            this.lblLookXe.Click += new System.EventHandler(this.lblLookXe_Click);
            // 
            // cklstCongViec
            // 
            this.cklstCongViec.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cklstCongViec.Appearance.Options.UseFont = true;
            this.cklstCongViec.Location = new System.Drawing.Point(647, 281);
            this.cklstCongViec.Name = "cklstCongViec";
            this.cklstCongViec.Size = new System.Drawing.Size(236, 315);
            this.cklstCongViec.TabIndex = 8;
            // 
            // lookLoaiXe
            // 
            this.lookLoaiXe.Location = new System.Drawing.Point(673, 157);
            this.lookLoaiXe.Name = "lookLoaiXe";
            this.lookLoaiXe.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lookLoaiXe.Properties.Appearance.Options.UseFont = true;
            this.lookLoaiXe.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.lookLoaiXe.Properties.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("MaLXe", "ID"),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("TenLXe", "Tên"),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("MoTa", "Mô tả"),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("deleted", "deleted", 20, DevExpress.Utils.FormatType.None, "", false, DevExpress.Utils.HorzAlignment.Default)});
            this.lookLoaiXe.Size = new System.Drawing.Size(210, 26);
            this.lookLoaiXe.TabIndex = 27;
            this.lookLoaiXe.Click += new System.EventHandler(this.texbox_Click);
            // 
            // lblClearKH
            // 
            this.lblClearKH.Appearance.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblClearKH.Appearance.ForeColor = System.Drawing.Color.Blue;
            this.lblClearKH.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblClearKH.Location = new System.Drawing.Point(322, 88);
            this.lblClearKH.Name = "lblClearKH";
            this.lblClearKH.Size = new System.Drawing.Size(35, 18);
            this.lblClearKH.TabIndex = 28;
            this.lblClearKH.Text = "Clear";
            this.lblClearKH.ToolTip = "Xóa thông tin đã nhập";
            this.lblClearKH.Click += new System.EventHandler(this.lblClearKH_Click);
            // 
            // lblClearXe
            // 
            this.lblClearXe.Appearance.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblClearXe.Appearance.ForeColor = System.Drawing.Color.Blue;
            this.lblClearXe.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblClearXe.Location = new System.Drawing.Point(768, 84);
            this.lblClearXe.Name = "lblClearXe";
            this.lblClearXe.Size = new System.Drawing.Size(35, 18);
            this.lblClearXe.TabIndex = 29;
            this.lblClearXe.Text = "Clear";
            this.lblClearXe.ToolTip = "Xóa thông tin xe đã nhập";
            this.lblClearXe.Click += new System.EventHandler(this.lblClearXe_Click);
            // 
            // labelControl13
            // 
            this.labelControl13.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl13.Location = new System.Drawing.Point(81, 402);
            this.labelControl13.Name = "labelControl13";
            this.labelControl13.Size = new System.Drawing.Size(54, 19);
            this.labelControl13.TabIndex = 30;
            this.labelControl13.Text = "Ghi chú";
            // 
            // txtNotes
            // 
            this.txtNotes.Location = new System.Drawing.Point(81, 427);
            this.txtNotes.Name = "txtNotes";
            this.txtNotes.Size = new System.Drawing.Size(341, 174);
            this.txtNotes.TabIndex = 31;
            // 
            // lblTitle
            // 
            this.lblTitle.Appearance.Font = new System.Drawing.Font("Tahoma", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Appearance.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lblTitle.Location = new System.Drawing.Point(81, 37);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(324, 33);
            this.lblTitle.TabIndex = 32;
            this.lblTitle.Text = "Thêm hóa đơn sửa chữa";
            // 
            // labelControl14
            // 
            this.labelControl14.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl14.Location = new System.Drawing.Point(81, 367);
            this.labelControl14.Name = "labelControl14";
            this.labelControl14.Size = new System.Drawing.Size(60, 19);
            this.labelControl14.TabIndex = 33;
            this.labelControl14.Text = "Tạm thu";
            // 
            // txtTamThu
            // 
            this.txtTamThu.EditValue = 0D;
            this.txtTamThu.Location = new System.Drawing.Point(212, 360);
            this.txtTamThu.Name = "txtTamThu";
            this.txtTamThu.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTamThu.Properties.Appearance.Options.UseFont = true;
            this.txtTamThu.Properties.Mask.EditMask = "n";
            this.txtTamThu.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtTamThu.Size = new System.Drawing.Size(210, 26);
            this.txtTamThu.TabIndex = 34;
            // 
            // UC_HoaDon
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.txtTamThu);
            this.Controls.Add(this.labelControl14);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.txtNotes);
            this.Controls.Add(this.labelControl13);
            this.Controls.Add(this.lblClearXe);
            this.Controls.Add(this.lblClearKH);
            this.Controls.Add(this.lookLoaiXe);
            this.Controls.Add(this.cklstCongViec);
            this.Controls.Add(this.lblLookXe);
            this.Controls.Add(this.lblLookKhachHang);
            this.Controls.Add(this.labelControl12);
            this.Controls.Add(this.ckbFinish);
            this.Controls.Add(this.dtDateCreate);
            this.Controls.Add(this.txtColor);
            this.Controls.Add(this.txtPlate);
            this.Controls.Add(this.txtPhoneNum);
            this.Controls.Add(this.txtAddress);
            this.Controls.Add(this.txtFullName);
            this.Controls.Add(this.labelControl11);
            this.Controls.Add(this.labelControl10);
            this.Controls.Add(this.labelControl9);
            this.Controls.Add(this.labelControl8);
            this.Controls.Add(this.labelControl7);
            this.Controls.Add(this.labelControl6);
            this.Controls.Add(this.labelControl5);
            this.Controls.Add(this.labelControl4);
            this.Controls.Add(this.labelControl3);
            this.Controls.Add(this.labelControl2);
            this.Controls.Add(this.labelControl1);
            this.Name = "UC_HoaDon";
            this.Size = new System.Drawing.Size(1000, 640);
            this.Load += new System.EventHandler(this.UC_HoaDon_Load);
            ((System.ComponentModel.ISupportInitialize)(this.txtFullName.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtAddress.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPhoneNum.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPlate.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtColor.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtDateCreate.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtDateCreate.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ckbFinish.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cklstCongViec)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookLoaiXe.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtNotes.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTamThu.Properties)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DevExpress.XtraEditors.LabelControl labelControl1;
        private DevExpress.XtraEditors.LabelControl labelControl2;
        private DevExpress.XtraEditors.LabelControl labelControl3;
        private DevExpress.XtraEditors.LabelControl labelControl4;
        private DevExpress.XtraEditors.LabelControl labelControl5;
        private DevExpress.XtraEditors.LabelControl labelControl6;
        private DevExpress.XtraEditors.LabelControl labelControl7;
        private DevExpress.XtraEditors.LabelControl labelControl8;
        private DevExpress.XtraEditors.LabelControl labelControl9;
        private DevExpress.XtraEditors.LabelControl labelControl10;
        private DevExpress.XtraEditors.LabelControl labelControl11;
        private DevExpress.XtraEditors.TextEdit txtFullName;
        private DevExpress.XtraEditors.TextEdit txtAddress;
        private DevExpress.XtraEditors.TextEdit txtPhoneNum;
        private DevExpress.XtraEditors.TextEdit txtPlate;
        private DevExpress.XtraEditors.TextEdit txtColor;
        private DevExpress.XtraEditors.DateEdit dtDateCreate;
        private DevExpress.XtraEditors.CheckEdit ckbFinish;
        private DevExpress.XtraEditors.LabelControl labelControl12;
        private DevExpress.XtraEditors.LabelControl lblLookKhachHang;
        private DevExpress.XtraEditors.LabelControl lblLookXe;
        private DevExpress.XtraEditors.CheckedListBoxControl cklstCongViec;
        private DevExpress.XtraEditors.LookUpEdit lookLoaiXe;
        private DevExpress.XtraEditors.LabelControl lblClearKH;
        private DevExpress.XtraEditors.LabelControl lblClearXe;
        private DevExpress.XtraEditors.LabelControl labelControl13;
        private DevExpress.XtraEditors.MemoEdit txtNotes;
        private DevExpress.XtraEditors.LabelControl lblTitle;
        private DevExpress.XtraEditors.LabelControl labelControl14;
        private DevExpress.XtraEditors.TextEdit txtTamThu;
    }
}
