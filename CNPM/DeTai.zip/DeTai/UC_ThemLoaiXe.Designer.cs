﻿namespace DeTai
{
    partial class UC_ThemLoaiXe
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UC_ThemLoaiXe));
            this.txtTenLXe = new DevExpress.XtraEditors.TextEdit();
            this.labelControl7 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl6 = new DevExpress.XtraEditors.LabelControl();
            this.lblTitle = new DevExpress.XtraEditors.LabelControl();
            this.txtMoTa = new DevExpress.XtraEditors.MemoEdit();
            this.txtMaLXe = new DevExpress.XtraEditors.TextEdit();
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.btnCheckMaCV = new DevExpress.XtraEditors.SimpleButton();
            ((System.ComponentModel.ISupportInitialize)(this.txtTenLXe.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMoTa.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMaLXe.Properties)).BeginInit();
            this.SuspendLayout();
            // 
            // txtTenLXe
            // 
            this.txtTenLXe.Location = new System.Drawing.Point(157, 137);
            this.txtTenLXe.Name = "txtTenLXe";
            this.txtTenLXe.Properties.Appearance.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTenLXe.Properties.Appearance.Options.UseFont = true;
            this.txtTenLXe.Size = new System.Drawing.Size(269, 26);
            this.txtTenLXe.TabIndex = 1;
            this.txtTenLXe.Click += new System.EventHandler(this.textBox_Click);
            // 
            // labelControl7
            // 
            this.labelControl7.Appearance.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl7.Location = new System.Drawing.Point(42, 172);
            this.labelControl7.Name = "labelControl7";
            this.labelControl7.Size = new System.Drawing.Size(40, 20);
            this.labelControl7.TabIndex = 58;
            this.labelControl7.Text = "Mô tả";
            // 
            // labelControl6
            // 
            this.labelControl6.Appearance.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl6.Location = new System.Drawing.Point(42, 144);
            this.labelControl6.Name = "labelControl6";
            this.labelControl6.Size = new System.Drawing.Size(75, 20);
            this.labelControl6.TabIndex = 57;
            this.labelControl6.Text = "Tên loại xe";
            // 
            // lblTitle
            // 
            this.lblTitle.Appearance.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Appearance.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lblTitle.Location = new System.Drawing.Point(42, 36);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(151, 29);
            this.lblTitle.TabIndex = 56;
            this.lblTitle.Text = "Thêm loại xe";
            // 
            // txtMoTa
            // 
            this.txtMoTa.Location = new System.Drawing.Point(157, 177);
            this.txtMoTa.Name = "txtMoTa";
            this.txtMoTa.Properties.Appearance.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMoTa.Properties.Appearance.Options.UseFont = true;
            this.txtMoTa.Size = new System.Drawing.Size(269, 104);
            this.txtMoTa.TabIndex = 2;
            this.txtMoTa.Click += new System.EventHandler(this.textBox_Click);
            // 
            // txtMaLXe
            // 
            this.txtMaLXe.Location = new System.Drawing.Point(157, 92);
            this.txtMaLXe.Name = "txtMaLXe";
            this.txtMaLXe.Properties.Appearance.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMaLXe.Properties.Appearance.Options.UseFont = true;
            this.txtMaLXe.Size = new System.Drawing.Size(269, 26);
            this.txtMaLXe.TabIndex = 0;
            this.txtMaLXe.Click += new System.EventHandler(this.textBox_Click);
            // 
            // labelControl1
            // 
            this.labelControl1.Appearance.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl1.Location = new System.Drawing.Point(42, 99);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(70, 20);
            this.labelControl1.TabIndex = 62;
            this.labelControl1.Text = "Mã loại xe";
            // 
            // btnCheckMaCV
            // 
            this.btnCheckMaCV.Image = ((System.Drawing.Image)(resources.GetObject("btnCheckMaCV.Image")));
            this.btnCheckMaCV.Location = new System.Drawing.Point(432, 93);
            this.btnCheckMaCV.Name = "btnCheckMaCV";
            this.btnCheckMaCV.Size = new System.Drawing.Size(25, 25);
            this.btnCheckMaCV.TabIndex = 72;
            this.btnCheckMaCV.Click += new System.EventHandler(this.btnCheckMaCV_Click);
            // 
            // UC_ThemLoaiXe
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.btnCheckMaCV);
            this.Controls.Add(this.txtMaLXe);
            this.Controls.Add(this.labelControl1);
            this.Controls.Add(this.txtMoTa);
            this.Controls.Add(this.txtTenLXe);
            this.Controls.Add(this.labelControl7);
            this.Controls.Add(this.labelControl6);
            this.Controls.Add(this.lblTitle);
            this.Name = "UC_ThemLoaiXe";
            this.Size = new System.Drawing.Size(481, 319);
            this.Load += new System.EventHandler(this.UC_ThemLoaiXe_Load);
            ((System.ComponentModel.ISupportInitialize)(this.txtTenLXe.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMoTa.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMaLXe.Properties)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DevExpress.XtraEditors.TextEdit txtTenLXe;
        private DevExpress.XtraEditors.LabelControl labelControl7;
        private DevExpress.XtraEditors.LabelControl labelControl6;
        private DevExpress.XtraEditors.LabelControl lblTitle;
        private DevExpress.XtraEditors.MemoEdit txtMoTa;
        private DevExpress.XtraEditors.TextEdit txtMaLXe;
        private DevExpress.XtraEditors.LabelControl labelControl1;
        private DevExpress.XtraEditors.SimpleButton btnCheckMaCV;
    }
}
