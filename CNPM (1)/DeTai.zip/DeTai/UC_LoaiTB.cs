﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DeTai
{
    public partial class UC_LoaiTB : UserControl, IController
    {
        SCXMdbDataContext db = new SCXMdbDataContext();
        LoaiThietBi loaithietbi;
        bool f_update = false;

        public UC_LoaiTB()
        {
            InitializeComponent();
        }

        public UC_LoaiTB(string id)
        {
            InitializeComponent();
            txtMa.Enabled = false;
            f_update = true;
            loaithietbi = db.LoaiThietBis.FirstOrDefault(p => p.MaLoaiTB == txtMa.Text);
            load();
        }

        public void save()
        {
            if (checkData() == false)
                return;

            if (f_update == false)
                insert();
            else
                update();
        }

        private void insert()
        {
            loaithietbi = new LoaiThietBi();
            loaithietbi.MaLoaiTB = txtMa.Text;
            loaithietbi.TenLoaiTB = txTen.Text;
            loaithietbi.MoTa = txtMoTa.Text;

            db.LoaiThietBis.InsertOnSubmit(loaithietbi);
            db.SubmitChanges();
        }

        private void update()
        {
            loaithietbi.MaLoaiTB = txtMa.Text;
            loaithietbi.TenLoaiTB = txTen.Text;
            loaithietbi.MoTa = txtMoTa.Text;

            db.SubmitChanges();
        }

        public void load()
        {
            txtMa.Text = loaithietbi.MaLoaiTB;
            txTen.Text = loaithietbi.TenLoaiTB;
            txtMoTa.Text = loaithietbi.MoTa;
        }

        public void Dispose()
        {
            if (f_update == false)
            {
                txtMa.ResetText();
                txTen.ResetText();
                txtMoTa.ResetText();
            }
            else
            {
                db.GetChangeSet().Updates.Clear();
                db.GetChangeSet().Inserts.Clear();
                load();
            }
        }

        private bool checkData()
        {
            bool result = true;
            Check check = new Check();

            result = check.checkEmpty(txtMa) && result;
            result = check.checkEmpty(txTen) && result;
            result = check.checkEmpty(txtMoTa) && result;

            return result;
        }

        private void UC_LoaiTB_Load(object sender, EventArgs e)
        {

        }
    }
}
