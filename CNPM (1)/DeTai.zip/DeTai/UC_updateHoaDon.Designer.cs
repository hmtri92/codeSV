﻿namespace DeTai
{
    partial class UC_updateHoaDon
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.seatchLookUpEditXe = new DevExpress.XtraEditors.Repository.RepositoryItemSearchLookUpEdit();
            this.lblTitle = new DevExpress.XtraEditors.LabelControl();
            this.txtNotes = new DevExpress.XtraEditors.MemoEdit();
            this.labelControl13 = new DevExpress.XtraEditors.LabelControl();
            this.lookLoaiXe = new DevExpress.XtraEditors.LookUpEdit();
            this.lblLookXe = new DevExpress.XtraEditors.LabelControl();
            this.lblLookKhachHang = new DevExpress.XtraEditors.LabelControl();
            this.labelControl12 = new DevExpress.XtraEditors.LabelControl();
            this.ckbFinish = new DevExpress.XtraEditors.CheckEdit();
            this.dtDateCreate = new DevExpress.XtraEditors.DateEdit();
            this.txtColor = new DevExpress.XtraEditors.TextEdit();
            this.txtPlate = new DevExpress.XtraEditors.TextEdit();
            this.txtPhoneNum = new DevExpress.XtraEditors.TextEdit();
            this.txtAddress = new DevExpress.XtraEditors.TextEdit();
            this.txtFullName = new DevExpress.XtraEditors.TextEdit();
            this.labelControl11 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl10 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl9 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl8 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl7 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl6 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl5 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl4 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl3 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl2 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.gridCongViec = new DevExpress.XtraGrid.GridControl();
            this.congViecSuaChuaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.gridviewCongViec = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.colCongViec = new DevExpress.XtraGrid.Columns.GridColumn();
            this.searchLookUpEditCongViec = new DevExpress.XtraEditors.Repository.RepositoryItemSearchLookUpEdit();
            this.congViecBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.repositoryItemSearchLookUpEdit2View = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.colnameCV = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colTienCV = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colSoLuongCV = new DevExpress.XtraGrid.Columns.GridColumn();
            this.coMaNV = new DevExpress.XtraGrid.Columns.GridColumn();
            this.SearchLookUpEditNhanVien = new DevExpress.XtraEditors.Repository.RepositoryItemSearchLookUpEdit();
            this.nhanVienBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.gridView1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.colMaNV = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colTenNV = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colSDTNV = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colThanhTienCV = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colDeleteCV = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemSearchLookUpEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemSearchLookUpEdit();
            this.repositoryItemSearchLookUpEdit1View = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridThietBi = new DevExpress.XtraGrid.GridControl();
            this.thietBiSuaChuaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.gridViewThietBi = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.colTenTB = new DevExpress.XtraGrid.Columns.GridColumn();
            this.searchLookUpEditThietBi = new DevExpress.XtraEditors.Repository.RepositoryItemSearchLookUpEdit();
            this.thietBiBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.repositoryItemTextEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            this.gridView2 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.colMaTB = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colTenTB2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colQuyCach = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colDonGiaTB = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colBaoHanh = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colSoLuongTB = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colThanhTienTB = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colXoaTB = new DevExpress.XtraGrid.Columns.GridColumn();
            this.labelControl14 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl15 = new DevExpress.XtraEditors.LabelControl();
            this.btnAddCongViec = new DevExpress.XtraEditors.SimpleButton();
            this.btnAddThietBi = new DevExpress.XtraEditors.SimpleButton();
            this.btnResetCV = new DevExpress.XtraEditors.SimpleButton();
            this.btnResetTB = new DevExpress.XtraEditors.SimpleButton();
            this.txtTongTien = new DevExpress.XtraEditors.LabelControl();
            this.btnXuatHoaDon = new DevExpress.XtraEditors.SimpleButton();
            this.labelControl16 = new DevExpress.XtraEditors.LabelControl();
            this.lblNguoiLapPhieu = new DevExpress.XtraEditors.LabelControl();
            this.labelControl17 = new DevExpress.XtraEditors.LabelControl();
            this.txtDaThu = new DevExpress.XtraEditors.TextEdit();
            ((System.ComponentModel.ISupportInitialize)(this.seatchLookUpEditXe)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtNotes.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookLoaiXe.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ckbFinish.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtDateCreate.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtDateCreate.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtColor.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPlate.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPhoneNum.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtAddress.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtFullName.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridCongViec)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.congViecSuaChuaBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridviewCongViec)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.searchLookUpEditCongViec)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.congViecBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemSearchLookUpEdit2View)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SearchLookUpEditNhanVien)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nhanVienBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemSearchLookUpEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemSearchLookUpEdit1View)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridThietBi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.thietBiSuaChuaBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewThietBi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.searchLookUpEditThietBi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.thietBiBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDaThu.Properties)).BeginInit();
            this.SuspendLayout();
            // 
            // seatchLookUpEditXe
            // 
            this.seatchLookUpEditXe.AutoHeight = false;
            this.seatchLookUpEditXe.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.seatchLookUpEditXe.DisplayMember = "TenCV";
            this.seatchLookUpEditXe.LookAndFeel.SkinName = "Caramel";
            this.seatchLookUpEditXe.Name = "seatchLookUpEditXe";
            this.seatchLookUpEditXe.ValueMember = "MaCV";
            // 
            // lblTitle
            // 
            this.lblTitle.Appearance.Font = new System.Drawing.Font("Tahoma", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Appearance.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lblTitle.Location = new System.Drawing.Point(28, 35);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(431, 33);
            this.lblTitle.TabIndex = 60;
            this.lblTitle.Text = "Sửa thông tin hóa đơn sửa chữa";
            // 
            // txtNotes
            // 
            this.txtNotes.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtNotes.Location = new System.Drawing.Point(827, 277);
            this.txtNotes.Name = "txtNotes";
            this.txtNotes.Size = new System.Drawing.Size(157, 340);
            this.txtNotes.TabIndex = 59;
            this.txtNotes.EditValueChanged += new System.EventHandler(this.txtNotes_EditValueChanged);
            // 
            // labelControl13
            // 
            this.labelControl13.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl13.Location = new System.Drawing.Point(827, 255);
            this.labelControl13.Name = "labelControl13";
            this.labelControl13.Size = new System.Drawing.Size(54, 19);
            this.labelControl13.TabIndex = 58;
            this.labelControl13.Text = "Ghi chú";
            // 
            // lookLoaiXe
            // 
            this.lookLoaiXe.Enabled = false;
            this.lookLoaiXe.Location = new System.Drawing.Point(461, 160);
            this.lookLoaiXe.Name = "lookLoaiXe";
            this.lookLoaiXe.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lookLoaiXe.Properties.Appearance.Options.UseFont = true;
            this.lookLoaiXe.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.lookLoaiXe.Properties.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("MaLXe", "ID"),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("TenLXe", "Tên"),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("MoTa", "Mô tả"),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("deleted", "deleted", 20, DevExpress.Utils.FormatType.None, "", false, DevExpress.Utils.HorzAlignment.Default)});
            this.lookLoaiXe.Size = new System.Drawing.Size(180, 26);
            this.lookLoaiXe.TabIndex = 55;
            // 
            // lblLookXe
            // 
            this.lblLookXe.Appearance.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLookXe.Appearance.ForeColor = System.Drawing.Color.Blue;
            this.lblLookXe.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblLookXe.Location = new System.Drawing.Point(499, 89);
            this.lblLookXe.Name = "lblLookXe";
            this.lblLookXe.Size = new System.Drawing.Size(51, 18);
            this.lblLookXe.TabIndex = 54;
            this.lblLookXe.Text = "Change";
            this.lblLookXe.ToolTip = "Nhập thông tin xe đã có";
            this.lblLookXe.Click += new System.EventHandler(this.lblLookXe_Click);
            // 
            // lblLookKhachHang
            // 
            this.lblLookKhachHang.Appearance.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLookKhachHang.Appearance.ForeColor = System.Drawing.Color.Blue;
            this.lblLookKhachHang.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblLookKhachHang.Location = new System.Drawing.Point(219, 89);
            this.lblLookKhachHang.Name = "lblLookKhachHang";
            this.lblLookKhachHang.Size = new System.Drawing.Size(51, 18);
            this.lblLookKhachHang.TabIndex = 53;
            this.lblLookKhachHang.Text = "Change";
            this.lblLookKhachHang.ToolTip = "Nhập thông khách hàngsẵn có";
            this.lblLookKhachHang.Click += new System.EventHandler(this.lblLookKhachHang_Click);
            // 
            // labelControl12
            // 
            this.labelControl12.Appearance.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl12.Location = new System.Drawing.Point(28, 251);
            this.labelControl12.Name = "labelControl12";
            this.labelControl12.Size = new System.Drawing.Size(166, 20);
            this.labelControl12.TabIndex = 52;
            this.labelControl12.Text = "Danh sách công việc";
            // 
            // ckbFinish
            // 
            this.ckbFinish.Location = new System.Drawing.Point(825, 199);
            this.ckbFinish.Name = "ckbFinish";
            this.ckbFinish.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ckbFinish.Properties.Appearance.Options.UseFont = true;
            this.ckbFinish.Properties.Caption = "Đã sửa xong";
            this.ckbFinish.Size = new System.Drawing.Size(154, 24);
            this.ckbFinish.TabIndex = 46;
            this.ckbFinish.EditValueChanged += new System.EventHandler(this.txtNotes_EditValueChanged);
            // 
            // dtDateCreate
            // 
            this.dtDateCreate.EditValue = null;
            this.dtDateCreate.Location = new System.Drawing.Point(827, 153);
            this.dtDateCreate.Name = "dtDateCreate";
            this.dtDateCreate.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtDateCreate.Properties.Appearance.Options.UseFont = true;
            this.dtDateCreate.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dtDateCreate.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dtDateCreate.Properties.CalendarTimeProperties.CloseUpKey = new DevExpress.Utils.KeyShortcut(System.Windows.Forms.Keys.F4);
            this.dtDateCreate.Properties.CalendarTimeProperties.PopupBorderStyle = DevExpress.XtraEditors.Controls.PopupBorderStyles.Default;
            this.dtDateCreate.Size = new System.Drawing.Size(152, 26);
            this.dtDateCreate.TabIndex = 44;
            this.dtDateCreate.EditValueChanged += new System.EventHandler(this.txtNotes_EditValueChanged);
            // 
            // txtColor
            // 
            this.txtColor.Enabled = false;
            this.txtColor.Location = new System.Drawing.Point(461, 201);
            this.txtColor.Name = "txtColor";
            this.txtColor.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtColor.Properties.Appearance.Options.UseFont = true;
            this.txtColor.Size = new System.Drawing.Size(180, 26);
            this.txtColor.TabIndex = 42;
            // 
            // txtPlate
            // 
            this.txtPlate.Enabled = false;
            this.txtPlate.Location = new System.Drawing.Point(461, 111);
            this.txtPlate.Name = "txtPlate";
            this.txtPlate.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPlate.Properties.Appearance.Options.UseFont = true;
            this.txtPlate.Size = new System.Drawing.Size(180, 26);
            this.txtPlate.TabIndex = 40;
            this.txtPlate.ToolTip = "Định dạng: 60y8-1234 hoặc 60y8-12345";
            // 
            // txtPhoneNum
            // 
            this.txtPhoneNum.Enabled = false;
            this.txtPhoneNum.Location = new System.Drawing.Point(166, 201);
            this.txtPhoneNum.Name = "txtPhoneNum";
            this.txtPhoneNum.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPhoneNum.Properties.Appearance.Options.UseFont = true;
            this.txtPhoneNum.Size = new System.Drawing.Size(180, 26);
            this.txtPhoneNum.TabIndex = 38;
            this.txtPhoneNum.ToolTip = "Định dạng 08-123-1234 hoặc 061-123-1234";
            // 
            // txtAddress
            // 
            this.txtAddress.Enabled = false;
            this.txtAddress.Location = new System.Drawing.Point(166, 157);
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAddress.Properties.Appearance.Options.UseFont = true;
            this.txtAddress.Size = new System.Drawing.Size(180, 26);
            this.txtAddress.TabIndex = 35;
            // 
            // txtFullName
            // 
            this.txtFullName.Enabled = false;
            this.txtFullName.Location = new System.Drawing.Point(166, 112);
            this.txtFullName.Name = "txtFullName";
            this.txtFullName.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFullName.Properties.Appearance.Options.UseFont = true;
            this.txtFullName.Size = new System.Drawing.Size(180, 26);
            this.txtFullName.TabIndex = 34;
            // 
            // labelControl11
            // 
            this.labelControl11.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl11.Location = new System.Drawing.Point(696, 204);
            this.labelControl11.Name = "labelControl11";
            this.labelControl11.Size = new System.Drawing.Size(74, 19);
            this.labelControl11.TabIndex = 51;
            this.labelControl11.Text = "Tình trạng";
            // 
            // labelControl10
            // 
            this.labelControl10.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl10.Location = new System.Drawing.Point(696, 159);
            this.labelControl10.Name = "labelControl10";
            this.labelControl10.Size = new System.Drawing.Size(111, 19);
            this.labelControl10.TabIndex = 50;
            this.labelControl10.Text = "Ngày làm phiếu";
            // 
            // labelControl9
            // 
            this.labelControl9.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl9.Location = new System.Drawing.Point(696, 92);
            this.labelControl9.Name = "labelControl9";
            this.labelControl9.Size = new System.Drawing.Size(148, 19);
            this.labelControl9.TabIndex = 49;
            this.labelControl9.Text = "Thông tin hóa đơn";
            // 
            // labelControl8
            // 
            this.labelControl8.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl8.Location = new System.Drawing.Point(375, 204);
            this.labelControl8.Name = "labelControl8";
            this.labelControl8.Size = new System.Drawing.Size(50, 19);
            this.labelControl8.TabIndex = 47;
            this.labelControl8.Text = "Màu xe";
            // 
            // labelControl7
            // 
            this.labelControl7.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl7.Location = new System.Drawing.Point(375, 157);
            this.labelControl7.Name = "labelControl7";
            this.labelControl7.Size = new System.Drawing.Size(50, 19);
            this.labelControl7.TabIndex = 45;
            this.labelControl7.Text = "Loại xe";
            // 
            // labelControl6
            // 
            this.labelControl6.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl6.Location = new System.Drawing.Point(375, 114);
            this.labelControl6.Name = "labelControl6";
            this.labelControl6.Size = new System.Drawing.Size(39, 19);
            this.labelControl6.TabIndex = 43;
            this.labelControl6.Text = "Số xe";
            // 
            // labelControl5
            // 
            this.labelControl5.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl5.Location = new System.Drawing.Point(375, 85);
            this.labelControl5.Name = "labelControl5";
            this.labelControl5.Size = new System.Drawing.Size(103, 19);
            this.labelControl5.TabIndex = 41;
            this.labelControl5.Text = "Thông tin xe";
            // 
            // labelControl4
            // 
            this.labelControl4.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl4.Location = new System.Drawing.Point(28, 204);
            this.labelControl4.Name = "labelControl4";
            this.labelControl4.Size = new System.Drawing.Size(93, 19);
            this.labelControl4.TabIndex = 39;
            this.labelControl4.Text = "Số điện thoại";
            // 
            // labelControl3
            // 
            this.labelControl3.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl3.Location = new System.Drawing.Point(28, 160);
            this.labelControl3.Name = "labelControl3";
            this.labelControl3.Size = new System.Drawing.Size(48, 19);
            this.labelControl3.TabIndex = 37;
            this.labelControl3.Text = "Địa chỉ";
            // 
            // labelControl2
            // 
            this.labelControl2.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl2.Location = new System.Drawing.Point(28, 115);
            this.labelControl2.Name = "labelControl2";
            this.labelControl2.Size = new System.Drawing.Size(113, 19);
            this.labelControl2.TabIndex = 36;
            this.labelControl2.Text = "Tên khách hàng";
            // 
            // labelControl1
            // 
            this.labelControl1.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl1.Location = new System.Drawing.Point(28, 86);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(176, 19);
            this.labelControl1.TabIndex = 33;
            this.labelControl1.Text = "Thông tin khách hàng";
            // 
            // gridCongViec
            // 
            this.gridCongViec.DataSource = this.congViecSuaChuaBindingSource;
            this.gridCongViec.Location = new System.Drawing.Point(28, 277);
            this.gridCongViec.MainView = this.gridviewCongViec;
            this.gridCongViec.Name = "gridCongViec";
            this.gridCongViec.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemSearchLookUpEdit1,
            this.searchLookUpEditCongViec,
            this.SearchLookUpEditNhanVien});
            this.gridCongViec.Size = new System.Drawing.Size(450, 340);
            this.gridCongViec.TabIndex = 61;
            this.gridCongViec.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridviewCongViec});
            // 
            // congViecSuaChuaBindingSource
            // 
            this.congViecSuaChuaBindingSource.DataSource = typeof(DeTai.CongViecSuaChua);
            // 
            // gridviewCongViec
            // 
            this.gridviewCongViec.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colCongViec,
            this.colSoLuongCV,
            this.coMaNV,
            this.colThanhTienCV,
            this.colDeleteCV});
            this.gridviewCongViec.GridControl = this.gridCongViec;
            this.gridviewCongViec.Name = "gridviewCongViec";
            this.gridviewCongViec.OptionsBehavior.AllowAddRows = DevExpress.Utils.DefaultBoolean.False;
            this.gridviewCongViec.OptionsBehavior.AllowDeleteRows = DevExpress.Utils.DefaultBoolean.False;
            this.gridviewCongViec.OptionsView.EnableAppearanceEvenRow = true;
            this.gridviewCongViec.OptionsView.EnableAppearanceOddRow = true;
            this.gridviewCongViec.ViewCaption = "Danh sách công việc";
            // 
            // colCongViec
            // 
            this.colCongViec.Caption = "Công việc";
            this.colCongViec.ColumnEdit = this.searchLookUpEditCongViec;
            this.colCongViec.FieldName = "MaCV";
            this.colCongViec.Name = "colCongViec";
            this.colCongViec.Visible = true;
            this.colCongViec.VisibleIndex = 0;
            this.colCongViec.Width = 207;
            // 
            // searchLookUpEditCongViec
            // 
            this.searchLookUpEditCongViec.AutoHeight = false;
            this.searchLookUpEditCongViec.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.searchLookUpEditCongViec.DataSource = this.congViecBindingSource;
            this.searchLookUpEditCongViec.DisplayMember = "TenCV";
            this.searchLookUpEditCongViec.Name = "searchLookUpEditCongViec";
            this.searchLookUpEditCongViec.ValueMember = "MaCV";
            this.searchLookUpEditCongViec.View = this.repositoryItemSearchLookUpEdit2View;
            // 
            // congViecBindingSource
            // 
            this.congViecBindingSource.DataSource = typeof(DeTai.CongViec);
            // 
            // repositoryItemSearchLookUpEdit2View
            // 
            this.repositoryItemSearchLookUpEdit2View.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colnameCV,
            this.colTienCV});
            this.repositoryItemSearchLookUpEdit2View.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus;
            this.repositoryItemSearchLookUpEdit2View.Name = "repositoryItemSearchLookUpEdit2View";
            this.repositoryItemSearchLookUpEdit2View.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.repositoryItemSearchLookUpEdit2View.OptionsView.ShowGroupPanel = false;
            // 
            // colnameCV
            // 
            this.colnameCV.Caption = "Tên công việc";
            this.colnameCV.FieldName = "TenCV";
            this.colnameCV.Name = "colnameCV";
            this.colnameCV.Visible = true;
            this.colnameCV.VisibleIndex = 0;
            // 
            // colTienCV
            // 
            this.colTienCV.Caption = "Tiền công";
            this.colTienCV.FieldName = "TienCong";
            this.colTienCV.Name = "colTienCV";
            this.colTienCV.Visible = true;
            this.colTienCV.VisibleIndex = 1;
            // 
            // colSoLuongCV
            // 
            this.colSoLuongCV.Caption = "Số lượng";
            this.colSoLuongCV.FieldName = "soluong";
            this.colSoLuongCV.Name = "colSoLuongCV";
            this.colSoLuongCV.Visible = true;
            this.colSoLuongCV.VisibleIndex = 2;
            this.colSoLuongCV.Width = 116;
            // 
            // coMaNV
            // 
            this.coMaNV.Caption = "Người thực hiện";
            this.coMaNV.ColumnEdit = this.SearchLookUpEditNhanVien;
            this.coMaNV.FieldName = "MaNV";
            this.coMaNV.Name = "coMaNV";
            this.coMaNV.Visible = true;
            this.coMaNV.VisibleIndex = 1;
            this.coMaNV.Width = 153;
            // 
            // SearchLookUpEditNhanVien
            // 
            this.SearchLookUpEditNhanVien.AutoHeight = false;
            this.SearchLookUpEditNhanVien.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.SearchLookUpEditNhanVien.DataSource = this.nhanVienBindingSource;
            this.SearchLookUpEditNhanVien.DisplayMember = "TenNV";
            this.SearchLookUpEditNhanVien.Name = "SearchLookUpEditNhanVien";
            this.SearchLookUpEditNhanVien.ValueMember = "MaNV";
            this.SearchLookUpEditNhanVien.View = this.gridView1;
            // 
            // nhanVienBindingSource
            // 
            this.nhanVienBindingSource.DataSource = typeof(DeTai.NhanVien);
            // 
            // gridView1
            // 
            this.gridView1.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colMaNV,
            this.colTenNV,
            this.colSDTNV});
            this.gridView1.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus;
            this.gridView1.Name = "gridView1";
            this.gridView1.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.gridView1.OptionsView.ShowGroupPanel = false;
            // 
            // colMaNV
            // 
            this.colMaNV.Caption = "Mã NV";
            this.colMaNV.FieldName = "MaNV";
            this.colMaNV.Name = "colMaNV";
            this.colMaNV.Visible = true;
            this.colMaNV.VisibleIndex = 0;
            // 
            // colTenNV
            // 
            this.colTenNV.Caption = "Họ tên";
            this.colTenNV.FieldName = "TenNV";
            this.colTenNV.Name = "colTenNV";
            this.colTenNV.Visible = true;
            this.colTenNV.VisibleIndex = 1;
            // 
            // colSDTNV
            // 
            this.colSDTNV.Caption = "Số điện thoại";
            this.colSDTNV.FieldName = "SDT";
            this.colSDTNV.Name = "colSDTNV";
            this.colSDTNV.Visible = true;
            this.colSDTNV.VisibleIndex = 2;
            // 
            // colThanhTienCV
            // 
            this.colThanhTienCV.Caption = "Tiền công";
            this.colThanhTienCV.FieldName = "ThanhTien";
            this.colThanhTienCV.Name = "colThanhTienCV";
            this.colThanhTienCV.OptionsColumn.AllowEdit = false;
            this.colThanhTienCV.Visible = true;
            this.colThanhTienCV.VisibleIndex = 3;
            this.colThanhTienCV.Width = 144;
            // 
            // colDeleteCV
            // 
            this.colDeleteCV.Caption = "Xóa";
            this.colDeleteCV.FieldName = "deleted";
            this.colDeleteCV.Name = "colDeleteCV";
            this.colDeleteCV.Visible = true;
            this.colDeleteCV.VisibleIndex = 4;
            this.colDeleteCV.Width = 73;
            // 
            // repositoryItemSearchLookUpEdit1
            // 
            this.repositoryItemSearchLookUpEdit1.AutoHeight = false;
            this.repositoryItemSearchLookUpEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemSearchLookUpEdit1.Name = "repositoryItemSearchLookUpEdit1";
            this.repositoryItemSearchLookUpEdit1.View = this.repositoryItemSearchLookUpEdit1View;
            // 
            // repositoryItemSearchLookUpEdit1View
            // 
            this.repositoryItemSearchLookUpEdit1View.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus;
            this.repositoryItemSearchLookUpEdit1View.Name = "repositoryItemSearchLookUpEdit1View";
            this.repositoryItemSearchLookUpEdit1View.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.repositoryItemSearchLookUpEdit1View.OptionsView.ShowGroupPanel = false;
            // 
            // gridThietBi
            // 
            this.gridThietBi.DataSource = this.thietBiSuaChuaBindingSource;
            this.gridThietBi.Location = new System.Drawing.Point(511, 277);
            this.gridThietBi.MainView = this.gridViewThietBi;
            this.gridThietBi.Name = "gridThietBi";
            this.gridThietBi.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.searchLookUpEditThietBi});
            this.gridThietBi.Size = new System.Drawing.Size(296, 340);
            this.gridThietBi.TabIndex = 63;
            this.gridThietBi.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridViewThietBi});
            // 
            // thietBiSuaChuaBindingSource
            // 
            this.thietBiSuaChuaBindingSource.DataSource = typeof(DeTai.ThietBiSuaChua);
            // 
            // gridViewThietBi
            // 
            this.gridViewThietBi.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colTenTB,
            this.colSoLuongTB,
            this.colThanhTienTB,
            this.colXoaTB});
            this.gridViewThietBi.GridControl = this.gridThietBi;
            this.gridViewThietBi.Name = "gridViewThietBi";
            this.gridViewThietBi.OptionsBehavior.AllowAddRows = DevExpress.Utils.DefaultBoolean.True;
            this.gridViewThietBi.OptionsBehavior.AllowDeleteRows = DevExpress.Utils.DefaultBoolean.True;
            // 
            // colTenTB
            // 
            this.colTenTB.Caption = "Thiết bị";
            this.colTenTB.ColumnEdit = this.searchLookUpEditThietBi;
            this.colTenTB.FieldName = "MaThietBi";
            this.colTenTB.Name = "colTenTB";
            this.colTenTB.Visible = true;
            this.colTenTB.VisibleIndex = 0;
            this.colTenTB.Width = 293;
            // 
            // searchLookUpEditThietBi
            // 
            this.searchLookUpEditThietBi.AutoHeight = false;
            this.searchLookUpEditThietBi.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.searchLookUpEditThietBi.DataSource = this.thietBiBindingSource;
            this.searchLookUpEditThietBi.DisplayMember = "TenThietBi";
            this.searchLookUpEditThietBi.Name = "searchLookUpEditThietBi";
            this.searchLookUpEditThietBi.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemTextEdit1});
            this.searchLookUpEditThietBi.ValueMember = "MaThietBi";
            this.searchLookUpEditThietBi.View = this.gridView2;
            // 
            // thietBiBindingSource
            // 
            this.thietBiBindingSource.DataSource = typeof(DeTai.ThietBi);
            // 
            // repositoryItemTextEdit1
            // 
            this.repositoryItemTextEdit1.AutoHeight = false;
            this.repositoryItemTextEdit1.Name = "repositoryItemTextEdit1";
            // 
            // gridView2
            // 
            this.gridView2.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colMaTB,
            this.colTenTB2,
            this.colQuyCach,
            this.colDonGiaTB,
            this.colBaoHanh});
            this.gridView2.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus;
            this.gridView2.Name = "gridView2";
            this.gridView2.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.gridView2.OptionsView.ShowGroupPanel = false;
            // 
            // colMaTB
            // 
            this.colMaTB.Caption = "Mã thiết bị";
            this.colMaTB.FieldName = "MaThietBi";
            this.colMaTB.Name = "colMaTB";
            this.colMaTB.Visible = true;
            this.colMaTB.VisibleIndex = 0;
            // 
            // colTenTB2
            // 
            this.colTenTB2.Caption = "Tên thiết bị";
            this.colTenTB2.FieldName = "TenThietBi";
            this.colTenTB2.Name = "colTenTB2";
            this.colTenTB2.Visible = true;
            this.colTenTB2.VisibleIndex = 1;
            // 
            // colQuyCach
            // 
            this.colQuyCach.Caption = "Quy cách";
            this.colQuyCach.FieldName = "QuyCach";
            this.colQuyCach.Name = "colQuyCach";
            this.colQuyCach.Visible = true;
            this.colQuyCach.VisibleIndex = 2;
            // 
            // colDonGiaTB
            // 
            this.colDonGiaTB.Caption = "Đơn giá";
            this.colDonGiaTB.FieldName = "DonGia";
            this.colDonGiaTB.Name = "colDonGiaTB";
            this.colDonGiaTB.Visible = true;
            this.colDonGiaTB.VisibleIndex = 3;
            // 
            // colBaoHanh
            // 
            this.colBaoHanh.Caption = "Bảo hành (ngày)";
            this.colBaoHanh.FieldName = "BaoHanh";
            this.colBaoHanh.Name = "colBaoHanh";
            this.colBaoHanh.Visible = true;
            this.colBaoHanh.VisibleIndex = 4;
            // 
            // colSoLuongTB
            // 
            this.colSoLuongTB.Caption = "số lượng";
            this.colSoLuongTB.FieldName = "soluong";
            this.colSoLuongTB.Name = "colSoLuongTB";
            this.colSoLuongTB.Visible = true;
            this.colSoLuongTB.VisibleIndex = 1;
            this.colSoLuongTB.Width = 142;
            // 
            // colThanhTienTB
            // 
            this.colThanhTienTB.Caption = "Thành tiền";
            this.colThanhTienTB.FieldName = "ThanhTien";
            this.colThanhTienTB.Name = "colThanhTienTB";
            this.colThanhTienTB.OptionsColumn.AllowEdit = false;
            this.colThanhTienTB.Visible = true;
            this.colThanhTienTB.VisibleIndex = 2;
            this.colThanhTienTB.Width = 183;
            // 
            // colXoaTB
            // 
            this.colXoaTB.Caption = "Xóa";
            this.colXoaTB.FieldName = "deleted";
            this.colXoaTB.Name = "colXoaTB";
            this.colXoaTB.Visible = true;
            this.colXoaTB.VisibleIndex = 3;
            // 
            // labelControl14
            // 
            this.labelControl14.Appearance.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl14.Location = new System.Drawing.Point(511, 251);
            this.labelControl14.Name = "labelControl14";
            this.labelControl14.Size = new System.Drawing.Size(146, 20);
            this.labelControl14.TabIndex = 62;
            this.labelControl14.Text = "Danh sách thiết bị";
            // 
            // labelControl15
            // 
            this.labelControl15.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.labelControl15.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl15.Appearance.ForeColor = System.Drawing.Color.Blue;
            this.labelControl15.Location = new System.Drawing.Point(791, 19);
            this.labelControl15.Name = "labelControl15";
            this.labelControl15.Size = new System.Drawing.Size(53, 19);
            this.labelControl15.TabIndex = 65;
            this.labelControl15.Text = "Đã thu:";
            // 
            // btnAddCongViec
            // 
            this.btnAddCongViec.Location = new System.Drawing.Point(200, 248);
            this.btnAddCongViec.Name = "btnAddCongViec";
            this.btnAddCongViec.Size = new System.Drawing.Size(47, 23);
            this.btnAddCongViec.TabIndex = 66;
            this.btnAddCongViec.Text = "Add";
            this.btnAddCongViec.Click += new System.EventHandler(this.btnAddCongViec_Click);
            // 
            // btnAddThietBi
            // 
            this.btnAddThietBi.Location = new System.Drawing.Point(669, 251);
            this.btnAddThietBi.Name = "btnAddThietBi";
            this.btnAddThietBi.Size = new System.Drawing.Size(47, 23);
            this.btnAddThietBi.TabIndex = 67;
            this.btnAddThietBi.Text = "Add";
            this.btnAddThietBi.Click += new System.EventHandler(this.btnAddThietBi_Click);
            // 
            // btnResetCV
            // 
            this.btnResetCV.Location = new System.Drawing.Point(253, 248);
            this.btnResetCV.Name = "btnResetCV";
            this.btnResetCV.Size = new System.Drawing.Size(41, 23);
            this.btnResetCV.TabIndex = 68;
            this.btnResetCV.Text = "Reset";
            this.btnResetCV.Click += new System.EventHandler(this.btnResetCV_Click);
            // 
            // btnResetTB
            // 
            this.btnResetTB.Location = new System.Drawing.Point(722, 251);
            this.btnResetTB.Name = "btnResetTB";
            this.btnResetTB.Size = new System.Drawing.Size(41, 23);
            this.btnResetTB.TabIndex = 69;
            this.btnResetTB.Text = "Reset";
            this.btnResetTB.Click += new System.EventHandler(this.btnResetTB_Click);
            // 
            // txtTongTien
            // 
            this.txtTongTien.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtTongTien.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTongTien.Appearance.ForeColor = System.Drawing.Color.Blue;
            this.txtTongTien.Location = new System.Drawing.Point(668, 19);
            this.txtTongTien.Name = "txtTongTien";
            this.txtTongTien.Size = new System.Drawing.Size(19, 19);
            this.txtTongTien.TabIndex = 70;
            this.txtTongTien.Text = "0đ";
            // 
            // btnXuatHoaDon
            // 
            this.btnXuatHoaDon.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnXuatHoaDon.Location = new System.Drawing.Point(895, 48);
            this.btnXuatHoaDon.Name = "btnXuatHoaDon";
            this.btnXuatHoaDon.Size = new System.Drawing.Size(84, 36);
            this.btnXuatHoaDon.TabIndex = 71;
            this.btnXuatHoaDon.Text = "Xuất hóa đơn";
            this.btnXuatHoaDon.Click += new System.EventHandler(this.btnXuatHoaDon_Click);
            // 
            // labelControl16
            // 
            this.labelControl16.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl16.Location = new System.Drawing.Point(696, 119);
            this.labelControl16.Name = "labelControl16";
            this.labelControl16.Size = new System.Drawing.Size(113, 19);
            this.labelControl16.TabIndex = 72;
            this.labelControl16.Text = "Người lập phiếu";
            // 
            // lblNguoiLapPhieu
            // 
            this.lblNguoiLapPhieu.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNguoiLapPhieu.Location = new System.Drawing.Point(827, 119);
            this.lblNguoiLapPhieu.Name = "lblNguoiLapPhieu";
            this.lblNguoiLapPhieu.Size = new System.Drawing.Size(32, 19);
            this.lblNguoiLapPhieu.TabIndex = 73;
            this.lblNguoiLapPhieu.Text = "Ng~";
            // 
            // labelControl17
            // 
            this.labelControl17.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.labelControl17.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl17.Appearance.ForeColor = System.Drawing.Color.Blue;
            this.labelControl17.Location = new System.Drawing.Point(582, 19);
            this.labelControl17.Name = "labelControl17";
            this.labelControl17.Size = new System.Drawing.Size(74, 19);
            this.labelControl17.TabIndex = 74;
            this.labelControl17.Text = "Tổng tiền:";
            // 
            // txtDaThu
            // 
            this.txtDaThu.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtDaThu.EditValue = 0D;
            this.txtDaThu.Enabled = false;
            this.txtDaThu.Location = new System.Drawing.Point(850, 16);
            this.txtDaThu.Name = "txtDaThu";
            this.txtDaThu.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDaThu.Properties.Appearance.Options.UseFont = true;
            this.txtDaThu.Size = new System.Drawing.Size(129, 26);
            this.txtDaThu.TabIndex = 75;
            // 
            // UC_updateHoaDon
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.txtDaThu);
            this.Controls.Add(this.labelControl17);
            this.Controls.Add(this.lblNguoiLapPhieu);
            this.Controls.Add(this.labelControl16);
            this.Controls.Add(this.btnXuatHoaDon);
            this.Controls.Add(this.txtTongTien);
            this.Controls.Add(this.btnResetTB);
            this.Controls.Add(this.btnResetCV);
            this.Controls.Add(this.btnAddThietBi);
            this.Controls.Add(this.btnAddCongViec);
            this.Controls.Add(this.labelControl15);
            this.Controls.Add(this.gridThietBi);
            this.Controls.Add(this.labelControl14);
            this.Controls.Add(this.gridCongViec);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.txtNotes);
            this.Controls.Add(this.labelControl13);
            this.Controls.Add(this.lookLoaiXe);
            this.Controls.Add(this.lblLookXe);
            this.Controls.Add(this.lblLookKhachHang);
            this.Controls.Add(this.labelControl12);
            this.Controls.Add(this.ckbFinish);
            this.Controls.Add(this.dtDateCreate);
            this.Controls.Add(this.txtColor);
            this.Controls.Add(this.txtPlate);
            this.Controls.Add(this.txtPhoneNum);
            this.Controls.Add(this.txtAddress);
            this.Controls.Add(this.txtFullName);
            this.Controls.Add(this.labelControl11);
            this.Controls.Add(this.labelControl10);
            this.Controls.Add(this.labelControl9);
            this.Controls.Add(this.labelControl8);
            this.Controls.Add(this.labelControl7);
            this.Controls.Add(this.labelControl6);
            this.Controls.Add(this.labelControl5);
            this.Controls.Add(this.labelControl4);
            this.Controls.Add(this.labelControl3);
            this.Controls.Add(this.labelControl2);
            this.Controls.Add(this.labelControl1);
            this.Name = "UC_updateHoaDon";
            this.Size = new System.Drawing.Size(1000, 640);
            this.Load += new System.EventHandler(this.UC_updateHoaDon_Load);
            ((System.ComponentModel.ISupportInitialize)(this.seatchLookUpEditXe)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtNotes.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookLoaiXe.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ckbFinish.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtDateCreate.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtDateCreate.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtColor.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPlate.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPhoneNum.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtAddress.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtFullName.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridCongViec)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.congViecSuaChuaBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridviewCongViec)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.searchLookUpEditCongViec)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.congViecBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemSearchLookUpEdit2View)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SearchLookUpEditNhanVien)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nhanVienBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemSearchLookUpEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemSearchLookUpEdit1View)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridThietBi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.thietBiSuaChuaBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewThietBi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.searchLookUpEditThietBi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.thietBiBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDaThu.Properties)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DevExpress.XtraEditors.LabelControl lblTitle;
        private DevExpress.XtraEditors.MemoEdit txtNotes;
        private DevExpress.XtraEditors.LabelControl labelControl13;
        private DevExpress.XtraEditors.LookUpEdit lookLoaiXe;
        private DevExpress.XtraEditors.LabelControl lblLookXe;
        private DevExpress.XtraEditors.LabelControl lblLookKhachHang;
        private DevExpress.XtraEditors.LabelControl labelControl12;
        private DevExpress.XtraEditors.CheckEdit ckbFinish;
        private DevExpress.XtraEditors.DateEdit dtDateCreate;
        private DevExpress.XtraEditors.TextEdit txtColor;
        private DevExpress.XtraEditors.TextEdit txtPlate;
        private DevExpress.XtraEditors.TextEdit txtPhoneNum;
        private DevExpress.XtraEditors.TextEdit txtAddress;
        private DevExpress.XtraEditors.TextEdit txtFullName;
        private DevExpress.XtraEditors.LabelControl labelControl11;
        private DevExpress.XtraEditors.LabelControl labelControl10;
        private DevExpress.XtraEditors.LabelControl labelControl9;
        private DevExpress.XtraEditors.LabelControl labelControl8;
        private DevExpress.XtraEditors.LabelControl labelControl7;
        private DevExpress.XtraEditors.LabelControl labelControl6;
        private DevExpress.XtraEditors.LabelControl labelControl5;
        private DevExpress.XtraEditors.LabelControl labelControl4;
        private DevExpress.XtraEditors.LabelControl labelControl3;
        private DevExpress.XtraEditors.LabelControl labelControl2;
        private DevExpress.XtraEditors.LabelControl labelControl1;
        private DevExpress.XtraGrid.GridControl gridCongViec;
        private DevExpress.XtraGrid.Views.Grid.GridView gridviewCongViec;
        private DevExpress.XtraGrid.GridControl gridThietBi;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewThietBi;
        private DevExpress.XtraGrid.Columns.GridColumn colTenTB;
        private DevExpress.XtraEditors.Repository.RepositoryItemSearchLookUpEdit searchLookUpEditThietBi;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView2;
        private DevExpress.XtraGrid.Columns.GridColumn colSoLuongTB;
        private DevExpress.XtraGrid.Columns.GridColumn colThanhTienTB;
        private DevExpress.XtraEditors.LabelControl labelControl14;
        private DevExpress.XtraGrid.Columns.GridColumn colCongViec;
        private DevExpress.XtraGrid.Columns.GridColumn colSoLuongCV;
        private DevExpress.XtraGrid.Columns.GridColumn colThanhTienCV;
        private DevExpress.XtraEditors.LabelControl labelControl15;
        private System.Windows.Forms.BindingSource congViecBindingSource;
        private System.Windows.Forms.BindingSource thietBiBindingSource;
        private DevExpress.XtraEditors.Repository.RepositoryItemSearchLookUpEdit seatchLookUpEditXe;
        private DevExpress.XtraEditors.Repository.RepositoryItemSearchLookUpEdit searchLookUpEditCongViec;
        private DevExpress.XtraGrid.Views.Grid.GridView repositoryItemSearchLookUpEdit2View;
        private DevExpress.XtraEditors.Repository.RepositoryItemSearchLookUpEdit repositoryItemSearchLookUpEdit1;
        private DevExpress.XtraGrid.Views.Grid.GridView repositoryItemSearchLookUpEdit1View;
        private DevExpress.XtraGrid.Columns.GridColumn colnameCV;
        private DevExpress.XtraGrid.Columns.GridColumn colTienCV;
        private DevExpress.XtraEditors.SimpleButton btnAddCongViec;
        private DevExpress.XtraEditors.SimpleButton btnAddThietBi;
        private System.Windows.Forms.BindingSource thietBiSuaChuaBindingSource;
        private DevExpress.XtraEditors.Repository.RepositoryItemTextEdit repositoryItemTextEdit1;
        private DevExpress.XtraGrid.Columns.GridColumn colDeleteCV;
        private DevExpress.XtraGrid.Columns.GridColumn colXoaTB;
        private DevExpress.XtraEditors.SimpleButton btnResetCV;
        private DevExpress.XtraEditors.SimpleButton btnResetTB;
        private DevExpress.XtraGrid.Columns.GridColumn colMaTB;
        private DevExpress.XtraGrid.Columns.GridColumn colTenTB2;
        private DevExpress.XtraGrid.Columns.GridColumn colQuyCach;
        private DevExpress.XtraGrid.Columns.GridColumn colDonGiaTB;
        private DevExpress.XtraGrid.Columns.GridColumn colBaoHanh;
        private System.Windows.Forms.BindingSource congViecSuaChuaBindingSource;
        private DevExpress.XtraEditors.LabelControl txtTongTien;
        private DevExpress.XtraEditors.SimpleButton btnXuatHoaDon;
        private DevExpress.XtraEditors.LabelControl labelControl16;
        private DevExpress.XtraEditors.LabelControl lblNguoiLapPhieu;
        private DevExpress.XtraGrid.Columns.GridColumn coMaNV;
        private DevExpress.XtraEditors.Repository.RepositoryItemSearchLookUpEdit SearchLookUpEditNhanVien;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView1;
        private System.Windows.Forms.BindingSource nhanVienBindingSource;
        private DevExpress.XtraGrid.Columns.GridColumn colMaNV;
        private DevExpress.XtraGrid.Columns.GridColumn colTenNV;
        private DevExpress.XtraGrid.Columns.GridColumn colSDTNV;
        private DevExpress.XtraEditors.LabelControl labelControl17;
        private DevExpress.XtraEditors.TextEdit txtDaThu;
    }
}
