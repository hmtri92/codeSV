package tdc.edu;

import java.util.Scanner;

public class BienLai {
	private KhachHang khachhang;
	private long chisocu;
	private long chisomoi;
	private float sotienphaitra;
	
	public BienLai(KhachHang khachhang, long chisocu, long chisomoi,
			float sotienphaitra) {
		super();
		this.khachhang = khachhang;
		this.chisocu = chisocu;
		this.chisomoi = chisomoi;
		this.sotienphaitra = sotienphaitra;
	}
	
	public KhachHang getKhachhang() {
		return khachhang;
	}
	public void setKhachhang(KhachHang khachhang) {
		this.khachhang = khachhang;
	}
	public long getChisocu() {
		return chisocu;
	}
	public void setChisocu(long chisocu) {
		this.chisocu = chisocu;
	}
	public long getChisomoi() {
		return chisomoi;
	}
	public void setChisomoi(long chisomoi) {
		this.chisomoi = chisomoi;
	}
	public float getSotienphaitra() {
		return sotienphaitra;
	}
	public void setSotienphaitra(float sotienphaitra) {
		this.sotienphaitra = sotienphaitra;
	}
	
	public void show()
	{
		khachhang.show();
		System.out.println("Chỉ số cũ: \t" + this.getChisocu());
		System.out.println("Chỉ số mới: \t" + this.getChisomoi());
		System.out.println("Thành tiền: \t" + this.getSotienphaitra());
	}

	public BienLai() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public void read()
	{
		Scanner scanner = new Scanner(System.in);
		System.out.print("Chỉ số cũ: ");
		this.chisocu = scanner.nextLong();
		
		System.out.print("Chỉ số mới: ");
		this.chisomoi = scanner.nextLong();
	}
}
