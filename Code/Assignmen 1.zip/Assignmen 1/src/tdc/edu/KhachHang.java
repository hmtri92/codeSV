package tdc.edu;

import java.util.Scanner;

public class KhachHang {
	private String ten;
	private String soNha;
	private String soCongTo;
	
	public KhachHang(String ten, String soNha, String soCongTo) {
		super();
		this.ten = ten;
		this.soNha = soNha;
		this.soCongTo = soCongTo;
	}
	
	public String getTen() {
		return ten;
	}
	public void setTen(String ten) {
		this.ten = ten;
	}
	public String getSoNha() {
		return soNha;
	}
	public void setSoNha(String soNha) {
		this.soNha = soNha;
	}
	public String getSoCongTo() {
		return soCongTo;
	}
	public void setSoCongTo(String soCongTo) {
		this.soCongTo = soCongTo;
	}
	
	public void show()
	{
		System.out.println("Họ tên: \t" + this.getTen());
		System.out.println("Số nhà: \t" + this.getSoNha());
		System.out.println("Số công tơ: \t" + this.getSoCongTo());
	}
	
	public void read()
	{
		Scanner scanner = new Scanner(System.in);
		System.out.print("Họ tên: ");
		this.ten = scanner.nextLine();
		
		System.out.print("Số nhà: ");
		this.soNha = scanner.nextLine();
		
		System.out.print("Số công tơ: ");
		this.soCongTo = scanner.nextLine();
	}

	public KhachHang() {
		super();
		// TODO Auto-generated constructor stub
	}
}
