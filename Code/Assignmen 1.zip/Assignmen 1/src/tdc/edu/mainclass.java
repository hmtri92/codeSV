package tdc.edu;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class mainclass {
	List<BienLai> lstBienLai;
	private static Scanner scanner;
	
	public mainclass() {
		super();
		lstBienLai = new ArrayList<BienLai>();
	}

	
	public void nhapthongtin(int n)
	{
		for (int i = 0; i < n; i++)
		{
			System.out.println(i + 1);
			BienLai bienlai = new BienLai();
			
			KhachHang khachhang = new KhachHang();
			khachhang.read();
			bienlai.read();
			bienlai.setKhachhang(khachhang);
			
			lstBienLai.add(bienlai);
		}
	}
	
	public void showAll()
	{
		for (int i = 0; i < lstBienLai.size(); i++)
		{
			System.out.println(i+1);
			lstBienLai.get(i).show();
		}
	}
	
	public void tinhtiendien()
	{
		for (int i = 0; i < lstBienLai.size(); i++)
		{
			BienLai element = lstBienLai.get(i);
			int elap = (int) (element.getChisomoi() - element.getChisocu());
			
			float sotienphaitra = 0;
			if (elap < 50)
			{
				sotienphaitra = elap * 1250;
			}
			else if (elap < 100)
			{
				sotienphaitra = (elap - 50) * 1500 + 62500;
			}
			else{
				sotienphaitra = 62500 + 7500 + (elap - 100) * 2000;
			}
			element.setSotienphaitra(sotienphaitra);
		}
	}
	
	public static void main(String [] args)
	{
		mainclass ms = new mainclass();
		int key;
		do {
			System.out.println("0. Thoát.");
			System.out.println("1. Nhập thông tin người dùng.");
			System.out.println("2. Hiễn thi thông tin.");
			System.out.println("3. Tính tiền điện.");
			
			scanner = new Scanner(System.in);
			key = scanner.nextInt();
			
			switch (key) {
			case 0:
				System.out.println("Thoát chương trình");
				break;
			case 1:
				System.out.println("Số phần tử muốn nhập: ");
				int n = scanner.nextInt();
				ms.nhapthongtin(n);
				break;
			case 2:
				System.out.println("----------Danh sách hóa đơn----------");
				ms.showAll();
				break;
			case 3:
				ms.tinhtiendien();
				break;

			default:
				System.out.println("Giá trị nhập không đúng");
				break;
			}
			
		} while(key != 0);
	}
}
