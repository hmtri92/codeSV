#include "Node.h"

template<class T>
Node<T>::Node(T value)
{
	this->pRe = NULL;
	this->value = value;
}

template<class T>
Node<T>::~Node()
{
}

template<class T>
T Node<T>::getValue()
{
	return this->value;
}
