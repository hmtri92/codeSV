#pragma once

#include <iostream>

using namespace std;

class Student
{
private:
	string name;
	float point;
public:
	Student();
	~Student();

	string getName();
	float getPoint();
	void setName(string name);
	void setPoint(float point);
};
