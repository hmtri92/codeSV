#include "Student.h"


Student::Student()
{
	this->name = "";
	this->point = 0;
}


Student::~Student()
{
}

string Student::getName()
{
	return this->name;
}

float Student::getPoint()
{
	return this->point;
}

void Student::setName(string name)
{
	this->name = name;
}

void Student::setPoint(float point)
{
	this->point = point;
}
