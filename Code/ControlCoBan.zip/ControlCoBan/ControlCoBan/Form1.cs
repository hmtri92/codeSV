﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ControlCoBan
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Bạn vừa bấm nút 1");
        }
        void HamThuHai(object objPhatSinhSuKien, EventArgs thamSoSuKien)
        {
            MessageBox.Show("Thông điệp từ hàm thứ hai");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox2.Text = "";
            if (sender == button2)
                MessageBox.Show("Bạn vừa bấm nút thứ 2");
            if (sender == button3)
                MessageBox.Show("Bạn vừa bấm nút thứ 3");
            ((Button)sender).Left += 30;
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("Bạn có chắc muốn đóng không?"
                                , "Hỏi cái"
                                , MessageBoxButtons.YesNo) != DialogResult.Yes)
            {
                e.Cancel = true;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
