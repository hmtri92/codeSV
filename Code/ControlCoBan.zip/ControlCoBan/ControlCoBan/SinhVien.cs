﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ControlCoBan
{
    class SinhVien
    {
        public string MSSV { get; set; }
        public string HoTen { get; set; }
        public double DiemTrungBinh { get; set; }
    }
}
