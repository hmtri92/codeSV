﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ControlCoBan
{
    public partial class FormMain : Form
    {
        public FormMain()
        {
            InitializeComponent();
        }
        Form1 f ;
        private void mởForm1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (f == null || f.IsDisposed)
            {
                f = new Form1();
                f.MdiParent = this;
            }
            f.Show();
            f.Activate();            
        }

        private void mởFormSựKiệnToolStripMenuItem_Click(object sender, EventArgs e){
            Form f2=null;
            foreach (Form fCon in this.MdiChildren){
                if (fCon is FormSuKienChuot_Phim)
                    f2 = fCon;
            }
            if (f2 == null)
            {
                f2 = new FormSuKienChuot_Phim();
                f2.MdiParent = this;
            }
            f2.Show();
            f2.Activate();
        }

        private void máyTínhToolStripMenuItem_Click(object sender, EventArgs e)
        {            
            foreach (Form fChild in this.MdiChildren)
            {
                if (fChild is FormMayTinh)
                {
                    fChild.Show();
                    fChild.Activate();
                    return;
                }
            }
            FormMayTinh fMTinh = new FormMayTinh();
            fMTinh.MdiParent = this;
            fMTinh.Show();
        }
    }
}
