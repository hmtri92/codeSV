﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ControlCoBan
{
    public partial class FormCacListControl : Form
    {
        public FormCacListControl()
        {
            InitializeComponent();
            
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex == -1)
            {
                MessageBox.Show("Chưa chọn anh nào");
                return;
            }

            MessageBox.Show("Bạn đang chọn: " + listBox1.SelectedItem.ToString());
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            if (txtHoTen.Text == "")
            {
                MessageBox.Show("Chua nhap ho ten");
                return;
            }
            listBox1.Items.Add(txtHoTen.Text);
        }

        private void btnXoaChon_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex == -1)
            {
                MessageBox.Show("Chưa chọn chưa xóa được");
                return;
            }
            //listBox1.Items.RemoveAt(listBox1.SelectedIndex);
            //while (listBox1.SelectedItems.Count > 0)
            //    listBox1.Items.Remove(listBox1.SelectedItems[0]);
            for (int i = listBox1.Items.Count - 1; i >= 0; i--)
            {
                if (listBox1.GetSelected(i) == true)
                    listBox1.Items.RemoveAt(i);
            }
        }
    }
}
