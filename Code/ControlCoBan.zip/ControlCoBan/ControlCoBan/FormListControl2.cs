﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ControlCoBan
{
    public partial class FormListControl2 : Form
    {
        public FormListControl2()
        {
            InitializeComponent();
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            SinhVien sv = new SinhVien();
            sv.HoTen = txtHoTen.Text;
            sv.DiemTrungBinh = double.Parse(txtDiemTB.Text);
            sv.MSSV = txtMSSV.Text;
            lstSinhVien.Items.Add(sv);
            lstSinhVien.DisplayMember = "HoTen";
        }

        private void lstSinhVien_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstSinhVien.SelectedIndex == -1)
                return;
            SinhVien svDuocChon = (SinhVien)lstSinhVien.SelectedItem;
            txtMSSV.Text = svDuocChon.MSSV;
            txtDiemTB.Text = svDuocChon.DiemTrungBinh.ToString();
            txtHoTen.Text = svDuocChon.HoTen;
        }

        private void FormListControl2_Load(object sender, EventArgs e)
        {
            SinhVien sv1 = new SinhVien { MSSV = "001", HoTen = "Lê Văn Tèo", DiemTrungBinh = 5.6 };
            SinhVien sv2 = new SinhVien { MSSV = "002", HoTen = "Trần Gì", DiemTrungBinh = 5 };
            SinhVien sv3 = new SinhVien { MSSV = "003", HoTen = "Nguyễn Có", DiemTrungBinh = 6 };
            SinhVien sv4 = new SinhVien { MSSV = "004", HoTen = "Đỗ Sỉ", DiemTrungBinh = 9 };
            lstSinhVien.Items.Add(sv1);
            lstSinhVien.Items.Add(sv2);
            lstSinhVien.Items.Add(sv3);
            lstSinhVien.Items.Add(sv4);
        }

        private void btnXoaChon_Click(object sender, EventArgs e)
        {

        }

        private void txtHoTen_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void txtMSSV_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void txtDiemTB_TextChanged(object sender, EventArgs e)
        {

        }

    }
}
