﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ControlCoBan
{
    public partial class FormListControl3 : Form
    {
        public FormListControl3()
        {
            InitializeComponent();
        }

        private void lstSinhVien_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstSinhVien.SelectedIndex == -1)
                return;
            SinhVien svDuocChon = (SinhVien)lstSinhVien.SelectedItem;
            txtMSSV.Text = svDuocChon.MSSV;
            txtDiemTB.Text = svDuocChon.DiemTrungBinh.ToString();
            txtHoTen.Text = svDuocChon.HoTen;
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            FormThemSinhVien f = new FormThemSinhVien();
            DialogResult rs = f.ShowDialog();//ShowDialog();
            if (rs == DialogResult.OK)
            {
                SinhVien sv = new SinhVien();
                sv.HoTen = f.txtHoTen.Text;
                sv.DiemTrungBinh = double.Parse(f.txtDiemTB.Text);
                sv.MSSV = f.txtMSSV.Text;
                lstSinhVien.Items.Add(sv);
                lstSinhVien.DisplayMember = "HoTen";
            }
        }

        private void btnXoaChon_Click(object sender, EventArgs e)
        {

        }

       
       
    }
}
