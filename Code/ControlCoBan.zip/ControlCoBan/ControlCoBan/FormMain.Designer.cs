﻿namespace ControlCoBan
{
    partial class FormMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.chứcNăngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mởForm1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mởFormSựKiệnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.máyTínhToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.chứcNăngToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(604, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // chứcNăngToolStripMenuItem
            // 
            this.chứcNăngToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mởForm1ToolStripMenuItem,
            this.mởFormSựKiệnToolStripMenuItem,
            this.máyTínhToolStripMenuItem});
            this.chứcNăngToolStripMenuItem.Name = "chứcNăngToolStripMenuItem";
            this.chứcNăngToolStripMenuItem.Size = new System.Drawing.Size(77, 20);
            this.chứcNăngToolStripMenuItem.Text = "Chức năng";
            // 
            // mởForm1ToolStripMenuItem
            // 
            this.mởForm1ToolStripMenuItem.Name = "mởForm1ToolStripMenuItem";
            this.mởForm1ToolStripMenuItem.Size = new System.Drawing.Size(162, 22);
            this.mởForm1ToolStripMenuItem.Text = "Mở form 1";
            this.mởForm1ToolStripMenuItem.Click += new System.EventHandler(this.mởForm1ToolStripMenuItem_Click);
            // 
            // mởFormSựKiệnToolStripMenuItem
            // 
            this.mởFormSựKiệnToolStripMenuItem.Name = "mởFormSựKiệnToolStripMenuItem";
            this.mởFormSựKiệnToolStripMenuItem.Size = new System.Drawing.Size(162, 22);
            this.mởFormSựKiệnToolStripMenuItem.Text = "Mở form Sự kiện";
            this.mởFormSựKiệnToolStripMenuItem.Click += new System.EventHandler(this.mởFormSựKiệnToolStripMenuItem_Click);
            // 
            // máyTínhToolStripMenuItem
            // 
            this.máyTínhToolStripMenuItem.Name = "máyTínhToolStripMenuItem";
            this.máyTínhToolStripMenuItem.Size = new System.Drawing.Size(162, 22);
            this.máyTínhToolStripMenuItem.Text = "Máy tính";
            this.máyTínhToolStripMenuItem.Click += new System.EventHandler(this.máyTínhToolStripMenuItem_Click);
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(604, 395);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "FormMain";
            this.Text = "FormMain";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem chứcNăngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mởForm1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mởFormSựKiệnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem máyTínhToolStripMenuItem;
    }
}