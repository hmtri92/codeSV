﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ControlCoBan
{
    public partial class FormMayTinh : Form
    {
        public FormMayTinh()
        {
            InitializeComponent();
        }

        private void btnSo_Click(object sender, EventArgs e)
        {
            Button nutSo = (Button)sender;
            txtManHinh.Text += nutSo.Text;
        }
    }
}
