﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ControlCoBan
{
    public partial class FormSuKienChuot_Phim : Form
    {
        public FormSuKienChuot_Phim()
        {
            InitializeComponent();
        }

        private void label3_MouseDown(object sender, MouseEventArgs e)
        {
            label1.Text = String.Format("MouseDown: X={0}, Y={1}", e.X, e.Y);
        }

        private void FormSuKienChuot_Phim_KeyDown(object sender, KeyEventArgs e)
        {
            label2.Text = string.Format("Key down: {0}", e.KeyCode);
            if (e.KeyData == Keys.A)
                e.Handled = true;
        }

        private void FormSuKienChuot_Phim_KeyPress(object sender, KeyPressEventArgs e)
        {
            label3.Text = string.Format("Key press: {0}", e.KeyChar);
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsNumber(e.KeyChar))
                e.Handled = true;
        }
    }
}
