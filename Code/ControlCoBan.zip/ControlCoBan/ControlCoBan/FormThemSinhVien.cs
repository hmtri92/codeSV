﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ControlCoBan
{
    public partial class FormThemSinhVien : Form
    {
        public FormThemSinhVien()
        {
            InitializeComponent();
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            if (txtHoTen.Text == "" || txtDiemTB.Text == "" || txtMSSV.Text == "")
            {
                MessageBox.Show("Chưa nhập đủ dữ liệu");
                return;
            }
            this.DialogResult = DialogResult.OK;
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }

        private void FormThemSinhVien_Load(object sender, EventArgs e)
        {

        }
    }
}
