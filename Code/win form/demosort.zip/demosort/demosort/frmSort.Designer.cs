﻿namespace demosort
{
    partial class frmSort
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmSort));
            this.rbcMenu = new DevExpress.XtraBars.Ribbon.RibbonControl();
            this.imageCollection1 = new DevExpress.Utils.ImageCollection(this.components);
            this.bbntHeapSort = new DevExpress.XtraBars.BarButtonItem();
            this.bbtnShellSort = new DevExpress.XtraBars.BarButtonItem();
            this.bbtnRandom = new DevExpress.XtraBars.BarButtonItem();
            this.bbtnNhapTC = new DevExpress.XtraBars.BarButtonItem();
            this.bbtnNhapFile = new DevExpress.XtraBars.BarButtonItem();
            this.barTocDo = new DevExpress.XtraBars.BarEditItem();
            this.repositoryItemTrackBar1 = new DevExpress.XtraEditors.Repository.RepositoryItemTrackBar();
            this.bbtnPause = new DevExpress.XtraBars.BarButtonItem();
            this.bbtnReset = new DevExpress.XtraBars.BarButtonItem();
            this.iExit = new DevExpress.XtraBars.BarButtonItem();
            this.btnSophantu = new DevExpress.XtraBars.BarEditItem();
            this.repositoryItemButtonEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit();
            this.btnNhapphantu = new DevExpress.XtraBars.BarEditItem();
            this.repositoryItemComboBox1 = new DevExpress.XtraEditors.Repository.RepositoryItemComboBox();
            this.bbtnHuongDan = new DevExpress.XtraBars.BarButtonItem();
            this.bbtnThongTin = new DevExpress.XtraBars.BarButtonItem();
            this.bbtnXuatFile = new DevExpress.XtraBars.BarButtonItem();
            this.bbtnDemoUngdung = new DevExpress.XtraBars.BarButtonItem();
            this.Home = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.rpNhap = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.rpSort = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.rpCaidat = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.rpExit = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPage3 = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPageGroup3 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPage2 = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPageGroup1 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup2 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.repositoryItemTextEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            this.repositoryItemButtonEdit2 = new DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit();
            this.repositoryItemCalcEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemCalcEdit();
            this.repositoryItemTextEdit2 = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            this.repositoryItemButtonEdit3 = new DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit();
            this.repositoryItemPopupContainerEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemPopupContainerEdit();
            this.repositoryItemPopupContainerEdit2 = new DevExpress.XtraEditors.Repository.RepositoryItemPopupContainerEdit();
            this.ribbonPage1 = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.picgoc = new System.Windows.Forms.PictureBox();
            this.img52labai = new System.Windows.Forms.ImageList(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.lblbuocnhay = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.rbcMenu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageCollection1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTrackBar1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEdit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCalcEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEdit3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemPopupContainerEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemPopupContainerEdit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picgoc)).BeginInit();
            this.SuspendLayout();
            // 
            // rbcMenu
            // 
            this.rbcMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.rbcMenu.BackgroundImage = global::demosort.Properties.Resources.Untitled_13;
            this.rbcMenu.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.rbcMenu.ColorScheme = DevExpress.XtraBars.Ribbon.RibbonControlColorScheme.Blue;
            this.rbcMenu.Cursor = System.Windows.Forms.Cursors.Default;
            this.rbcMenu.ExpandCollapseItem.Id = 0;
            this.rbcMenu.Images = this.imageCollection1;
            this.rbcMenu.Items.AddRange(new DevExpress.XtraBars.BarItem[] {
            this.rbcMenu.ExpandCollapseItem,
            this.bbntHeapSort,
            this.bbtnShellSort,
            this.bbtnRandom,
            this.bbtnNhapTC,
            this.bbtnNhapFile,
            this.barTocDo,
            this.bbtnPause,
            this.bbtnReset,
            this.iExit,
            this.btnSophantu,
            this.btnNhapphantu,
            this.bbtnHuongDan,
            this.bbtnThongTin,
            this.bbtnXuatFile,
            this.bbtnDemoUngdung});
            this.rbcMenu.LargeImages = this.imageCollection1;
            this.rbcMenu.Location = new System.Drawing.Point(0, 0);
            this.rbcMenu.MaxItemId = 36;
            this.rbcMenu.Name = "rbcMenu";
            this.rbcMenu.Pages.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPage[] {
            this.Home,
            this.ribbonPage3,
            this.ribbonPage2});
            this.rbcMenu.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemTrackBar1,
            this.repositoryItemTextEdit1,
            this.repositoryItemButtonEdit1,
            this.repositoryItemButtonEdit2,
            this.repositoryItemCalcEdit1,
            this.repositoryItemTextEdit2,
            this.repositoryItemButtonEdit3,
            this.repositoryItemComboBox1,
            this.repositoryItemPopupContainerEdit1,
            this.repositoryItemPopupContainerEdit2});
            this.rbcMenu.Size = new System.Drawing.Size(1104, 142);
            this.rbcMenu.ToolbarLocation = DevExpress.XtraBars.Ribbon.RibbonQuickAccessToolbarLocation.Above;
            // 
            // imageCollection1
            // 
            this.imageCollection1.ImageSize = new System.Drawing.Size(32, 32);
            this.imageCollection1.ImageStream = ((DevExpress.Utils.ImageCollectionStreamer)(resources.GetObject("imageCollection1.ImageStream")));
            this.imageCollection1.Images.SetKeyName(0, "Drafts_16x16.png");
            this.imageCollection1.Images.SetKeyName(1, "pause-icon-th.png");
            this.imageCollection1.Images.SetKeyName(2, "play-icon-th.png");
            this.imageCollection1.Images.SetKeyName(3, "reset.png");
            this.imageCollection1.Images.SetKeyName(4, "Ribbon_Open_32x32.png");
            this.imageCollection1.Images.SetKeyName(5, "run.png");
            this.imageCollection1.Images.SetKeyName(6, "sort.png");
            this.imageCollection1.Images.SetKeyName(7, "sort1.png");
            this.imageCollection1.Images.SetKeyName(8, "book.png");
            this.imageCollection1.Images.SetKeyName(9, "me.png");
            this.imageCollection1.Images.SetKeyName(10, "Inbox_16x16.png");
            // 
            // bbntHeapSort
            // 
            this.bbntHeapSort.Caption = "Heap Sort";
            this.bbntHeapSort.Id = 1;
            this.bbntHeapSort.ImageIndex = 7;
            this.bbntHeapSort.Name = "bbntHeapSort";
            this.bbntHeapSort.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.bbntHeapSort.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.bbntHeapSort_ItemClick);
            // 
            // bbtnShellSort
            // 
            this.bbtnShellSort.Caption = "Shell Sort";
            this.bbtnShellSort.Id = 2;
            this.bbtnShellSort.ImageIndex = 6;
            this.bbtnShellSort.Name = "bbtnShellSort";
            this.bbtnShellSort.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.bbtnShellSort.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.bbtnShellSort_ItemClick);
            // 
            // bbtnRandom
            // 
            this.bbtnRandom.Caption = "Ramdom";
            this.bbtnRandom.Id = 5;
            this.bbtnRandom.LargeGlyph = global::demosort.Properties.Resources.random;
            this.bbtnRandom.Name = "bbtnRandom";
            this.bbtnRandom.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.bbtnRandom_ItemClick);
            // 
            // bbtnNhapTC
            // 
            this.bbtnNhapTC.Caption = "Nhập thủ công";
            this.bbtnNhapTC.Id = 6;
            this.bbtnNhapTC.ImageIndex = 0;
            this.bbtnNhapTC.Name = "bbtnNhapTC";
            this.bbtnNhapTC.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.bbtnNhapTC_ItemClick);
            // 
            // bbtnNhapFile
            // 
            this.bbtnNhapFile.Caption = "Nhập Từ File";
            this.bbtnNhapFile.Id = 7;
            this.bbtnNhapFile.ImageIndex = 4;
            this.bbtnNhapFile.Name = "bbtnNhapFile";
            this.bbtnNhapFile.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.bbtnNhapFile_ItemClick);
            // 
            // barTocDo
            // 
            this.barTocDo.Caption = "Tốc độ chạy";
            this.barTocDo.Edit = this.repositoryItemTrackBar1;
            this.barTocDo.EditValue = 1;
            this.barTocDo.Id = 8;
            this.barTocDo.ImageIndex = 5;
            this.barTocDo.Name = "barTocDo";
            this.barTocDo.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.barTocDo.Width = 100;
            this.barTocDo.EditValueChanged += new System.EventHandler(this.barTocDo_EditValueChanged);
            // 
            // repositoryItemTrackBar1
            // 
            this.repositoryItemTrackBar1.LabelAppearance.Options.UseTextOptions = true;
            this.repositoryItemTrackBar1.LabelAppearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.repositoryItemTrackBar1.Name = "repositoryItemTrackBar1";
            // 
            // bbtnPause
            // 
            this.bbtnPause.Caption = "Pause";
            this.bbtnPause.Id = 9;
            this.bbtnPause.LargeImageIndex = 1;
            this.bbtnPause.Name = "bbtnPause";
            this.bbtnPause.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.bbtnPause_ItemClick);
            // 
            // bbtnReset
            // 
            this.bbtnReset.Caption = "Reset";
            this.bbtnReset.Id = 10;
            this.bbtnReset.ImageIndex = 3;
            this.bbtnReset.Name = "bbtnReset";
            this.bbtnReset.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.bbtnReset.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.bbtnReset_ItemClick);
            // 
            // iExit
            // 
            this.iExit.Caption = "Exit";
            this.iExit.Id = 11;
            this.iExit.LargeGlyph = global::demosort.Properties.Resources.Ribbon_Exit_32x32;
            this.iExit.Name = "iExit";
            this.iExit.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.iExit.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.iExit_ItemClick);
            // 
            // btnSophantu
            // 
            this.btnSophantu.Caption = "Số Phần tử";
            this.btnSophantu.Edit = this.repositoryItemButtonEdit1;
            this.btnSophantu.EditValue = "";
            this.btnSophantu.Id = 16;
            this.btnSophantu.Name = "btnSophantu";
            this.btnSophantu.Visibility = DevExpress.XtraBars.BarItemVisibility.OnlyInCustomizing;
            this.btnSophantu.HiddenEditor += new DevExpress.XtraBars.ItemClickEventHandler(this.btnSophantu_HiddenEditor);
            // 
            // repositoryItemButtonEdit1
            // 
            this.repositoryItemButtonEdit1.AutoHeight = false;
            this.repositoryItemButtonEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.repositoryItemButtonEdit1.Name = "repositoryItemButtonEdit1";
            // 
            // btnNhapphantu
            // 
            this.btnNhapphantu.Caption = "Nhập phần tử";
            this.btnNhapphantu.Edit = this.repositoryItemComboBox1;
            this.btnNhapphantu.Id = 21;
            this.btnNhapphantu.Name = "btnNhapphantu";
            this.btnNhapphantu.Visibility = DevExpress.XtraBars.BarItemVisibility.OnlyInCustomizing;
            this.btnNhapphantu.HiddenEditor += new DevExpress.XtraBars.ItemClickEventHandler(this.btnNhapphantu_HiddenEditor);
            // 
            // repositoryItemComboBox1
            // 
            this.repositoryItemComboBox1.AutoHeight = false;
            this.repositoryItemComboBox1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemComboBox1.Name = "repositoryItemComboBox1";
            // 
            // bbtnHuongDan
            // 
            this.bbtnHuongDan.Caption = "Hướng Dẫn";
            this.bbtnHuongDan.Id = 27;
            this.bbtnHuongDan.ImageIndex = 8;
            this.bbtnHuongDan.LargeImageIndex = 8;
            this.bbtnHuongDan.Name = "bbtnHuongDan";
            this.bbtnHuongDan.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.bbtnHuongDan.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.bbtnHuongDan_ItemClick);
            // 
            // bbtnThongTin
            // 
            this.bbtnThongTin.Caption = "Thông tin Sinh Viên";
            this.bbtnThongTin.Id = 28;
            this.bbtnThongTin.LargeImageIndex = 9;
            this.bbtnThongTin.Name = "bbtnThongTin";
            this.bbtnThongTin.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.bbtnThongTin_ItemClick);
            // 
            // bbtnXuatFile
            // 
            this.bbtnXuatFile.Caption = "Xuất File";
            this.bbtnXuatFile.Id = 33;
            this.bbtnXuatFile.ImageIndex = 10;
            this.bbtnXuatFile.Name = "bbtnXuatFile";
            this.bbtnXuatFile.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.bbtnXuatFile_ItemClick);
            // 
            // bbtnDemoUngdung
            // 
            this.bbtnDemoUngdung.Caption = "Run";
            this.bbtnDemoUngdung.Id = 35;
            this.bbtnDemoUngdung.ImageIndex = 5;
            this.bbtnDemoUngdung.Name = "bbtnDemoUngdung";
            this.bbtnDemoUngdung.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.bbtnDemoUngdung.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.bbtnDemoUngdung_ItemClick);
            // 
            // Home
            // 
            this.Home.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.rpNhap,
            this.rpSort,
            this.rpCaidat,
            this.rpExit});
            this.Home.Name = "Home";
            this.Home.Text = "Home";
            // 
            // rpNhap
            // 
            this.rpNhap.ItemLinks.Add(this.bbtnRandom);
            this.rpNhap.ItemLinks.Add(this.bbtnNhapTC);
            this.rpNhap.ItemLinks.Add(this.bbtnNhapFile);
            this.rpNhap.ItemLinks.Add(this.bbtnXuatFile);
            this.rpNhap.ItemLinks.Add(this.btnSophantu, true);
            this.rpNhap.ItemLinks.Add(this.btnNhapphantu);
            this.rpNhap.Name = "rpNhap";
            this.rpNhap.Text = "Nhập dữ liệu";
            // 
            // rpSort
            // 
            this.rpSort.ItemLinks.Add(this.bbntHeapSort);
            this.rpSort.ItemLinks.Add(this.bbtnShellSort);
            this.rpSort.Name = "rpSort";
            this.rpSort.Text = "Sort";
            // 
            // rpCaidat
            // 
            this.rpCaidat.ItemLinks.Add(this.barTocDo);
            this.rpCaidat.ItemLinks.Add(this.bbtnReset);
            this.rpCaidat.ItemLinks.Add(this.bbtnPause);
            this.rpCaidat.Name = "rpCaidat";
            this.rpCaidat.Text = "Cài đặt";
            // 
            // rpExit
            // 
            this.rpExit.ItemLinks.Add(this.iExit);
            this.rpExit.Name = "rpExit";
            this.rpExit.Text = "Exit";
            // 
            // ribbonPage3
            // 
            this.ribbonPage3.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.ribbonPageGroup3});
            this.ribbonPage3.Name = "ribbonPage3";
            this.ribbonPage3.Text = "Ứng dụng";
            // 
            // ribbonPageGroup3
            // 
            this.ribbonPageGroup3.ItemLinks.Add(this.bbtnDemoUngdung);
            this.ribbonPageGroup3.Name = "ribbonPageGroup3";
            this.ribbonPageGroup3.Text = "Chương trình ứng dụng";
            // 
            // ribbonPage2
            // 
            this.ribbonPage2.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.ribbonPageGroup1,
            this.ribbonPageGroup2});
            this.ribbonPage2.Name = "ribbonPage2";
            this.ribbonPage2.Text = "Thông Tin";
            // 
            // ribbonPageGroup1
            // 
            this.ribbonPageGroup1.ItemLinks.Add(this.bbtnHuongDan);
            this.ribbonPageGroup1.Name = "ribbonPageGroup1";
            this.ribbonPageGroup1.Text = "Hướng dẫn                        ";
            // 
            // ribbonPageGroup2
            // 
            this.ribbonPageGroup2.ItemLinks.Add(this.bbtnThongTin);
            this.ribbonPageGroup2.Name = "ribbonPageGroup2";
            this.ribbonPageGroup2.Text = "Thông tin.................";
            // 
            // repositoryItemTextEdit1
            // 
            this.repositoryItemTextEdit1.AutoHeight = false;
            this.repositoryItemTextEdit1.Name = "repositoryItemTextEdit1";
            // 
            // repositoryItemButtonEdit2
            // 
            this.repositoryItemButtonEdit2.AutoHeight = false;
            this.repositoryItemButtonEdit2.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.repositoryItemButtonEdit2.Name = "repositoryItemButtonEdit2";
            // 
            // repositoryItemCalcEdit1
            // 
            this.repositoryItemCalcEdit1.AutoHeight = false;
            this.repositoryItemCalcEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemCalcEdit1.Name = "repositoryItemCalcEdit1";
            // 
            // repositoryItemTextEdit2
            // 
            this.repositoryItemTextEdit2.AutoHeight = false;
            this.repositoryItemTextEdit2.Name = "repositoryItemTextEdit2";
            // 
            // repositoryItemButtonEdit3
            // 
            this.repositoryItemButtonEdit3.AutoHeight = false;
            this.repositoryItemButtonEdit3.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.repositoryItemButtonEdit3.Name = "repositoryItemButtonEdit3";
            // 
            // repositoryItemPopupContainerEdit1
            // 
            this.repositoryItemPopupContainerEdit1.AutoHeight = false;
            this.repositoryItemPopupContainerEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemPopupContainerEdit1.Name = "repositoryItemPopupContainerEdit1";
            // 
            // repositoryItemPopupContainerEdit2
            // 
            this.repositoryItemPopupContainerEdit2.AutoHeight = false;
            this.repositoryItemPopupContainerEdit2.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemPopupContainerEdit2.Name = "repositoryItemPopupContainerEdit2";
            // 
            // ribbonPage1
            // 
            this.ribbonPage1.Name = "ribbonPage1";
            this.ribbonPage1.Text = "ribbonPage1";
            // 
            // picgoc
            // 
            this.picgoc.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.picgoc.BackgroundImage = global::demosort.Properties.Resources.Untitled_1;
            this.picgoc.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picgoc.Location = new System.Drawing.Point(12, 486);
            this.picgoc.Name = "picgoc";
            this.picgoc.Size = new System.Drawing.Size(75, 90);
            this.picgoc.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picgoc.TabIndex = 1;
            this.picgoc.TabStop = false;
            this.picgoc.Click += new System.EventHandler(this.picgoc_Click);
            // 
            // img52labai
            // 
            this.img52labai.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("img52labai.ImageStream")));
            this.img52labai.TransparentColor = System.Drawing.Color.Transparent;
            this.img52labai.Images.SetKeyName(0, "2bich.jpg");
            this.img52labai.Images.SetKeyName(1, "2chuon.jpg");
            this.img52labai.Images.SetKeyName(2, "2ro.jpg");
            this.img52labai.Images.SetKeyName(3, "2co.jpg");
            this.img52labai.Images.SetKeyName(4, "3bich.jpg");
            this.img52labai.Images.SetKeyName(5, "3chuon.jpg");
            this.img52labai.Images.SetKeyName(6, "3ro.jpg");
            this.img52labai.Images.SetKeyName(7, "3co.jpg");
            this.img52labai.Images.SetKeyName(8, "4cich.jpg");
            this.img52labai.Images.SetKeyName(9, "4chuon.jpg");
            this.img52labai.Images.SetKeyName(10, "4ro.jpg");
            this.img52labai.Images.SetKeyName(11, "4co.jpg");
            this.img52labai.Images.SetKeyName(12, "5bich.jpg");
            this.img52labai.Images.SetKeyName(13, "5chuon.jpg");
            this.img52labai.Images.SetKeyName(14, "5ro.jpg");
            this.img52labai.Images.SetKeyName(15, "5co.jpg");
            this.img52labai.Images.SetKeyName(16, "6bich.jpg");
            this.img52labai.Images.SetKeyName(17, "6chuon.jpg");
            this.img52labai.Images.SetKeyName(18, "6ro.jpg");
            this.img52labai.Images.SetKeyName(19, "6co.jpg");
            this.img52labai.Images.SetKeyName(20, "7bich.jpg");
            this.img52labai.Images.SetKeyName(21, "7chuon.jpg");
            this.img52labai.Images.SetKeyName(22, "7ro.jpg");
            this.img52labai.Images.SetKeyName(23, "7co.jpg");
            this.img52labai.Images.SetKeyName(24, "8bich.jpg");
            this.img52labai.Images.SetKeyName(25, "8chuon.jpg");
            this.img52labai.Images.SetKeyName(26, "8ro.jpg");
            this.img52labai.Images.SetKeyName(27, "8co.jpg");
            this.img52labai.Images.SetKeyName(28, "9bich.jpg");
            this.img52labai.Images.SetKeyName(29, "9chuon.jpg");
            this.img52labai.Images.SetKeyName(30, "9ro.jpg");
            this.img52labai.Images.SetKeyName(31, "9co.jpg");
            this.img52labai.Images.SetKeyName(32, "10bich.jpg");
            this.img52labai.Images.SetKeyName(33, "10chuon.jpg");
            this.img52labai.Images.SetKeyName(34, "10ro.jpg");
            this.img52labai.Images.SetKeyName(35, "10co.jpg");
            this.img52labai.Images.SetKeyName(36, "jbich.jpg");
            this.img52labai.Images.SetKeyName(37, "jchuon.jpg");
            this.img52labai.Images.SetKeyName(38, "jro.jpg");
            this.img52labai.Images.SetKeyName(39, "jco.jpg");
            this.img52labai.Images.SetKeyName(40, "qbich.jpg");
            this.img52labai.Images.SetKeyName(41, "qchuon.jpg");
            this.img52labai.Images.SetKeyName(42, "qro.jpg");
            this.img52labai.Images.SetKeyName(43, "qco.jpg");
            this.img52labai.Images.SetKeyName(44, "kbich.jpg");
            this.img52labai.Images.SetKeyName(45, "kchuon.jpg");
            this.img52labai.Images.SetKeyName(46, "kro.jpg");
            this.img52labai.Images.SetKeyName(47, "kco.jpg");
            this.img52labai.Images.SetKeyName(48, "abich.jpg");
            this.img52labai.Images.SetKeyName(49, "achuon.jpg");
            this.img52labai.Images.SetKeyName(50, "aro.jpg");
            this.img52labai.Images.SetKeyName(51, "aco.jpg");
            this.img52labai.Images.SetKeyName(52, "Untitled-1.jpg");
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(24, 163);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 22);
            this.label1.TabIndex = 3;
            this.label1.Text = "Bước nhảy:";
            // 
            // lblbuocnhay
            // 
            this.lblbuocnhay.AutoSize = true;
            this.lblbuocnhay.BackColor = System.Drawing.Color.Transparent;
            this.lblbuocnhay.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblbuocnhay.Location = new System.Drawing.Point(130, 163);
            this.lblbuocnhay.Name = "lblbuocnhay";
            this.lblbuocnhay.Size = new System.Drawing.Size(0, 22);
            this.lblbuocnhay.TabIndex = 3;
            // 
            // frmSort
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Thistle;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1104, 587);
            this.Controls.Add(this.lblbuocnhay);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.picgoc);
            this.Controls.Add(this.rbcMenu);
            this.DoubleBuffered = true;
            this.Name = "frmSort";
            this.Text = "Demo Sort";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmSort_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Resize += new System.EventHandler(this.frmSort_Resize);
            ((System.ComponentModel.ISupportInitialize)(this.rbcMenu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageCollection1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTrackBar1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEdit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCalcEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEdit3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemPopupContainerEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemPopupContainerEdit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picgoc)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DevExpress.XtraBars.Ribbon.RibbonControl rbcMenu;
        private DevExpress.XtraBars.Ribbon.RibbonPage Home;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup rpSort;
        private DevExpress.XtraBars.BarButtonItem bbntHeapSort;
        private DevExpress.XtraBars.BarButtonItem bbtnShellSort;
        private DevExpress.XtraBars.BarButtonItem bbtnRandom;
        private DevExpress.XtraBars.BarButtonItem bbtnNhapTC;
        private DevExpress.XtraBars.BarButtonItem bbtnNhapFile;
        private DevExpress.XtraBars.BarEditItem barTocDo;
        private DevExpress.XtraEditors.Repository.RepositoryItemTrackBar repositoryItemTrackBar1;
        private DevExpress.XtraBars.BarButtonItem bbtnPause;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup rpNhap;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup rpCaidat;
        private DevExpress.XtraBars.BarButtonItem bbtnReset;
        private DevExpress.XtraBars.BarButtonItem iExit;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup rpExit;
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage1;
        private System.Windows.Forms.PictureBox picgoc;
        private System.Windows.Forms.ImageList img52labai;
        private DevExpress.XtraBars.BarEditItem btnSophantu;
        private DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit repositoryItemButtonEdit1;
        private DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit repositoryItemButtonEdit2;
        private DevExpress.XtraEditors.Repository.RepositoryItemTextEdit repositoryItemTextEdit1;
        private DevExpress.XtraEditors.Repository.RepositoryItemTextEdit repositoryItemTextEdit2;
        private DevExpress.XtraEditors.Repository.RepositoryItemCalcEdit repositoryItemCalcEdit1;
        private DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit repositoryItemButtonEdit3;
        private DevExpress.XtraBars.BarEditItem btnNhapphantu;
        private DevExpress.XtraEditors.Repository.RepositoryItemComboBox repositoryItemComboBox1;
        private DevExpress.XtraEditors.Repository.RepositoryItemPopupContainerEdit repositoryItemPopupContainerEdit1;
        private DevExpress.XtraEditors.Repository.RepositoryItemPopupContainerEdit repositoryItemPopupContainerEdit2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblbuocnhay;
        private DevExpress.Utils.ImageCollection imageCollection1;
        private DevExpress.XtraBars.BarButtonItem bbtnHuongDan;
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage2;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup1;
        private DevExpress.XtraBars.BarButtonItem bbtnThongTin;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup2;
        private DevExpress.XtraBars.BarButtonItem bbtnXuatFile;
        private DevExpress.XtraBars.BarButtonItem bbtnDemoUngdung;
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage3;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup3;

    }
}

