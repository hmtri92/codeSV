﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace demosort
{
    public partial class FormUngDung : Form
    {
        long sophantu;
        long[] LPhanTu;
        long[] mangtam;
        ulong sophephoanvi = 0, sophepsosanh = 0;

        public FormUngDung()
        {
            InitializeComponent();
        }

        private void txtSophantu_Click(object sender, EventArgs e)
        {
            txtSophantu.ResetText();
        }

        private void btnRandum_Click(object sender, EventArgs e)
        {
            long number1 = 0;
            bool t = long.TryParse(txtSophantu.Text, out number1);
            if (t == false)
            {
                MessageBox.Show("Nhập số phần tử là số", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            sophantu = long.Parse(txtSophantu.Text);
            LPhanTu = new long[sophantu];
            Random r = new Random();
            for (int i = 0; i < sophantu; i++ )
            {
                LPhanTu[i] = r.Next(-999999999,999999999);
            }
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            txtSophantu.ResetText();

            txtHeaptime.ResetText();
            txtHeapsosanh.ResetText();
            txtHeaphoanvi.ResetText();
            
            txtShellhoanvi.ResetText();
            txtShellsosanh.ResetText();
            txtShelltime.ResetText();

            txtQuickhoanvi.ResetText();
            txtQuicksosanh.ResetText();
            txtQuicktime.ResetText();
        }

        private void btnXuatFile_Click(object sender, EventArgs e)
        {
            SaveFileDialog save = new SaveFileDialog();
            save.Title = "Mở File";
            save.Filter = "File text|*.txt|All File|*.*";
            DialogResult tv = save.ShowDialog();
            if (tv == DialogResult.OK)
            {
                xuatFile(save.FileName);
            }     
        }

        void xuatFile(string name)
        {
            StreamWriter sw = new StreamWriter(name);
            sw.WriteLine(sophantu);
            for (int i = 0; i < sophantu; i++)
            {
                sw.Write(LPhanTu[i]);
                sw.Write(" ");
            }
            sw.Close();

        }

        private void btnHeap_Click(object sender, EventArgs e)
        {
            chepmang();
            sophepsosanh = 0;
            sophephoanvi = 0;
            txtHeaptime.ResetText();
            txtHeapsosanh.ResetText();
            txtHeaphoanvi.ResetText();

            DateTime timebatdau = new DateTime();
            timebatdau = DateTime.Now;
            taoHeap(sophantu / 2, sophantu);
            long max = sophantu - 1;

            while (max > 0)
            {
                long temp = mangtam[0];
                mangtam[0] = mangtam[max];
                mangtam[max] = temp;

                sophephoanvi++;
                sophepsosanh++;

                taoHeap(0, --max);
            }
            TimeSpan time = DateTime.Now - timebatdau;
            double milisecond = time.TotalMilliseconds;
            txtHeaptime.Text = milisecond.ToString();
            txtHeapsosanh.Text = sophepsosanh.ToString();
            txtHeaphoanvi.Text = sophephoanvi.ToString();
        }

        void taoHeap(long giatri, long max)   // giatri: vị trí bắt đầu tạo heap; max: tạo heap tới vị trí max.
        {
            if (giatri == max)
                return;
            for (long i = giatri; i >= 0; i--)  // Tạo heap từ nơi bắt đầu trở về đầu mảng.
            {                
                long vt, dich = i;
                // Xác định vị trí cần đổi
                try // Trường hợp phần tử i có i*2 && i*2 + 1
                {
                    vt = (mangtam[i * 2] > mangtam[2 * i + 1]) ? (i * 2) : (i * 2 + 1);
                    sophepsosanh++;
                }
                catch (System.Exception ex)
                {
                    vt = i * 2;
                }
                //if (vt > max)
                //    vt = i * 2;
                long temp = mangtam[i];
                while (vt < max)
                {
                    sophepsosanh++;
                    if (temp < mangtam[vt])
                    {
                        sophepsosanh++;

                        mangtam[dich] = mangtam[vt];
                        dich = vt;
                        sophephoanvi++;
                        try
                        {
                            vt = mangtam[vt * 2] > mangtam[2 * vt + 1] ? vt * 2 : vt * 2 + 1;
                            sophepsosanh++;
                        }
                        catch (System.Exception)
                        {
                            vt *= 2;
                        }
                    }
                    else
                    {
                        break;
                    }
                }
                mangtam[dich] = temp;
            }
        }

        private void btnShell_Click(object sender, EventArgs e)
        {
            chepmang();
            txtShellhoanvi.ResetText();
            txtShellsosanh.ResetText();
            txtShelltime.ResetText();
            sophephoanvi = 0;
            sophepsosanh = 0;

            DateTime timebatdau = new DateTime();
            timebatdau = DateTime.Now;

            long i, j, buocnhay, temp;
            buocnhay = sophantu / 2;
            while (buocnhay > 0)
            {
                sophepsosanh++;
                for (i = buocnhay; i < sophantu; i++)
                {
                    sophepsosanh++;
                    j = i;
                    temp = mangtam[i];
                    while (j >= buocnhay && mangtam[j - buocnhay] > temp)
                    {
                        sophepsosanh += 2;
                        mangtam[j] = mangtam[j - buocnhay];
                        sophephoanvi++;
                        j -= buocnhay;
                    }
                    mangtam[j] = temp;
                }
                buocnhay /= 2;
            }

            TimeSpan time = DateTime.Now - timebatdau;
            double milisecond = time.TotalMilliseconds;
            txtShelltime.Text = milisecond.ToString();
            txtShellsosanh.Text = sophepsosanh.ToString();
            txtShellhoanvi.Text = sophephoanvi.ToString();
        }

        private void btnxuatketqua_Click(object sender, EventArgs e)
        {
            SaveFileDialog save = new SaveFileDialog();
            save.Title = "Mở File";
            save.Filter = "File text|*.txt|All File|*.*";
            DialogResult tv = save.ShowDialog();
            if (tv == DialogResult.OK)
            {
                xuatketqua(save.FileName);
            }    
        }
        void xuatketqua(string name)
        {
            StreamWriter sw = new StreamWriter(name);
            sw.WriteLine(sophantu);
            for (int i = 0; i < sophantu; i++)
            {
                sw.Write(mangtam[i]);
                sw.Write(" ");
            }
            sw.Close();

        }

        private void btbQuick_Click(object sender, EventArgs e)
        {
            chepmang();
            txtQuickhoanvi.ResetText();
            txtQuicksosanh.ResetText();
            txtQuicktime.ResetText();
            sophephoanvi = 0;
            sophepsosanh = 0;

            DateTime timebatdau = new DateTime();
            timebatdau = DateTime.Now;

            QuickSort(0, sophantu - 1);

            TimeSpan time = DateTime.Now - timebatdau;
            double milisecond = time.TotalMilliseconds;
            txtQuicktime.Text = milisecond.ToString();
            txtQuicksosanh.Text = sophepsosanh.ToString();
            txtQuickhoanvi.Text = sophephoanvi.ToString();
        }
        void QuickSort( long l, long r)
		{
			long i = l, j = r;
			long x = mangtam[(l+r)/2];
			do
            {
                while (mangtam[i] < x)
                {
                    sophepsosanh++;
                    i++;
                    try
                    {
                        long pp = mangtam[i];
                    }
                    catch (System.Exception)
                    {
                    	break;
                    }
                }
                while (mangtam[j] > x)
                {
                    sophepsosanh++;
                    j--;
                    try
                    {
                        long pp1 = mangtam[j];
                    }
                    catch (System.Exception)
                    {
                        break;
                    }
                }
				
				if (i <= j)
				{
                    sophephoanvi++;
                    sophepsosanh++;
                    long temp = mangtam[i];
                    mangtam[i] = mangtam[j];
                    mangtam[j] = temp;
					i++; j--;
				}
			} while (i < j);
			if ( l < j) QuickSort(l, j);
			if (i < r) QuickSort(i, r);
		}

        void chepmang()
        {
            mangtam = new long[sophantu];
            for (int i = 0; i < sophantu; i++ )
            {
                mangtam[i] = LPhanTu[i];
            }
        }

    }
}
