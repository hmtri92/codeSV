﻿namespace demosort
{
    partial class FormUngDung
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormUngDung));
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.btnReset = new System.Windows.Forms.Button();
            this.btnRandum = new System.Windows.Forms.Button();
            this.txtSophantu = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtQuicksosanh = new System.Windows.Forms.TextBox();
            this.txtHeapsosanh = new System.Windows.Forms.TextBox();
            this.txtShellhoanvi = new System.Windows.Forms.TextBox();
            this.txtHeaphoanvi = new System.Windows.Forms.TextBox();
            this.txtShellsosanh = new System.Windows.Forms.TextBox();
            this.txtQuicktime = new System.Windows.Forms.TextBox();
            this.txtQuickhoanvi = new System.Windows.Forms.TextBox();
            this.txtShelltime = new System.Windows.Forms.TextBox();
            this.txtHeaptime = new System.Windows.Forms.TextBox();
            this.btbQuick = new System.Windows.Forms.Button();
            this.btnShell = new System.Windows.Forms.Button();
            this.btnHeap = new System.Windows.Forms.Button();
            this.bbtnXuatFile = new System.Windows.Forms.Button();
            this.btnxuatketqua = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.Transparent;
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.bbtnXuatFile);
            this.groupBox2.Controls.Add(this.btnReset);
            this.groupBox2.Controls.Add(this.btnRandum);
            this.groupBox2.Controls.Add(this.txtSophantu);
            this.groupBox2.Location = new System.Drawing.Point(24, 104);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(595, 61);
            this.groupBox2.TabIndex = 23;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Randum - Reset";
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Location = new System.Drawing.Point(13, 12);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(81, 31);
            this.label4.TabIndex = 18;
            this.label4.Text = "Tạo bộ test mới";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnReset
            // 
            this.btnReset.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnReset.BackgroundImage")));
            this.btnReset.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReset.Image = ((System.Drawing.Image)(resources.GetObject("btnReset.Image")));
            this.btnReset.Location = new System.Drawing.Point(423, 14);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(77, 29);
            this.btnReset.TabIndex = 14;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // btnRandum
            // 
            this.btnRandum.BackColor = System.Drawing.Color.Transparent;
            this.btnRandum.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnRandum.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRandum.ForeColor = System.Drawing.Color.Black;
            this.btnRandum.Image = ((System.Drawing.Image)(resources.GetObject("btnRandum.Image")));
            this.btnRandum.Location = new System.Drawing.Point(328, 13);
            this.btnRandum.Name = "btnRandum";
            this.btnRandum.Size = new System.Drawing.Size(80, 31);
            this.btnRandum.TabIndex = 13;
            this.btnRandum.Text = "Random";
            this.btnRandum.UseVisualStyleBackColor = false;
            this.btnRandum.Click += new System.EventHandler(this.btnRandum_Click);
            // 
            // txtSophantu
            // 
            this.txtSophantu.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSophantu.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txtSophantu.Location = new System.Drawing.Point(120, 14);
            this.txtSophantu.Multiline = true;
            this.txtSophantu.Name = "txtSophantu";
            this.txtSophantu.Size = new System.Drawing.Size(183, 30);
            this.txtSophantu.TabIndex = 12;
            this.txtSophantu.Text = "Nhập số phần tử cần tạo mới";
            this.txtSophantu.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtSophantu.Click += new System.EventHandler(this.txtSophantu_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.txtQuicksosanh);
            this.groupBox1.Controls.Add(this.txtHeapsosanh);
            this.groupBox1.Controls.Add(this.txtShellhoanvi);
            this.groupBox1.Controls.Add(this.txtHeaphoanvi);
            this.groupBox1.Controls.Add(this.txtShellsosanh);
            this.groupBox1.Controls.Add(this.txtQuicktime);
            this.groupBox1.Controls.Add(this.txtQuickhoanvi);
            this.groupBox1.Controls.Add(this.txtShelltime);
            this.groupBox1.Controls.Add(this.txtHeaptime);
            this.groupBox1.Controls.Add(this.btnxuatketqua);
            this.groupBox1.Controls.Add(this.btbQuick);
            this.groupBox1.Controls.Add(this.btnShell);
            this.groupBox1.Controls.Add(this.btnHeap);
            this.groupBox1.Location = new System.Drawing.Point(24, 166);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(595, 188);
            this.groupBox1.TabIndex = 22;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Sắp xếp";
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Location = new System.Drawing.Point(404, 2);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(107, 38);
            this.label3.TabIndex = 17;
            this.label3.Text = "Số phép\r\nhoán vị";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Location = new System.Drawing.Point(282, 2);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 38);
            this.label2.TabIndex = 16;
            this.label2.Text = "Số phép\r\nso sánh";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Location = new System.Drawing.Point(134, 2);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(107, 38);
            this.label1.TabIndex = 15;
            this.label1.Text = "Thời gian\r\n(milisecond)";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtQuicksosanh
            // 
            this.txtQuicksosanh.Location = new System.Drawing.Point(266, 142);
            this.txtQuicksosanh.Multiline = true;
            this.txtQuicksosanh.Name = "txtQuicksosanh";
            this.txtQuicksosanh.Size = new System.Drawing.Size(112, 30);
            this.txtQuicksosanh.TabIndex = 11;
            this.txtQuicksosanh.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtHeapsosanh
            // 
            this.txtHeapsosanh.Location = new System.Drawing.Point(266, 43);
            this.txtHeapsosanh.Multiline = true;
            this.txtHeapsosanh.Name = "txtHeapsosanh";
            this.txtHeapsosanh.Size = new System.Drawing.Size(112, 30);
            this.txtHeapsosanh.TabIndex = 10;
            this.txtHeapsosanh.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtShellhoanvi
            // 
            this.txtShellhoanvi.Location = new System.Drawing.Point(405, 94);
            this.txtShellhoanvi.Multiline = true;
            this.txtShellhoanvi.Name = "txtShellhoanvi";
            this.txtShellhoanvi.Size = new System.Drawing.Size(115, 30);
            this.txtShellhoanvi.TabIndex = 9;
            this.txtShellhoanvi.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtHeaphoanvi
            // 
            this.txtHeaphoanvi.Location = new System.Drawing.Point(405, 43);
            this.txtHeaphoanvi.Multiline = true;
            this.txtHeaphoanvi.Name = "txtHeaphoanvi";
            this.txtHeaphoanvi.Size = new System.Drawing.Size(115, 30);
            this.txtHeaphoanvi.TabIndex = 8;
            this.txtHeaphoanvi.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtShellsosanh
            // 
            this.txtShellsosanh.Location = new System.Drawing.Point(266, 94);
            this.txtShellsosanh.Multiline = true;
            this.txtShellsosanh.Name = "txtShellsosanh";
            this.txtShellsosanh.Size = new System.Drawing.Size(112, 30);
            this.txtShellsosanh.TabIndex = 7;
            this.txtShellsosanh.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtQuicktime
            // 
            this.txtQuicktime.Location = new System.Drawing.Point(137, 142);
            this.txtQuicktime.Multiline = true;
            this.txtQuicktime.Name = "txtQuicktime";
            this.txtQuicktime.Size = new System.Drawing.Size(107, 30);
            this.txtQuicktime.TabIndex = 6;
            this.txtQuicktime.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtQuickhoanvi
            // 
            this.txtQuickhoanvi.Location = new System.Drawing.Point(405, 142);
            this.txtQuickhoanvi.Multiline = true;
            this.txtQuickhoanvi.Name = "txtQuickhoanvi";
            this.txtQuickhoanvi.Size = new System.Drawing.Size(115, 30);
            this.txtQuickhoanvi.TabIndex = 5;
            this.txtQuickhoanvi.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtShelltime
            // 
            this.txtShelltime.Location = new System.Drawing.Point(137, 94);
            this.txtShelltime.Multiline = true;
            this.txtShelltime.Name = "txtShelltime";
            this.txtShelltime.Size = new System.Drawing.Size(107, 30);
            this.txtShelltime.TabIndex = 4;
            this.txtShelltime.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtHeaptime
            // 
            this.txtHeaptime.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtHeaptime.Location = new System.Drawing.Point(137, 43);
            this.txtHeaptime.Multiline = true;
            this.txtHeaptime.Name = "txtHeaptime";
            this.txtHeaptime.Size = new System.Drawing.Size(107, 30);
            this.txtHeaptime.TabIndex = 3;
            this.txtHeaptime.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btbQuick
            // 
            this.btbQuick.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btbQuick.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btbQuick.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btbQuick.ForeColor = System.Drawing.Color.Black;
            this.btbQuick.Image = ((System.Drawing.Image)(resources.GetObject("btbQuick.Image")));
            this.btbQuick.Location = new System.Drawing.Point(13, 142);
            this.btbQuick.Name = "btbQuick";
            this.btbQuick.Size = new System.Drawing.Size(97, 30);
            this.btbQuick.TabIndex = 2;
            this.btbQuick.Text = "Quick Sort";
            this.btbQuick.UseVisualStyleBackColor = false;
            this.btbQuick.Click += new System.EventHandler(this.btbQuick_Click);
            // 
            // btnShell
            // 
            this.btnShell.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btnShell.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnShell.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnShell.ForeColor = System.Drawing.Color.Black;
            this.btnShell.Image = ((System.Drawing.Image)(resources.GetObject("btnShell.Image")));
            this.btnShell.Location = new System.Drawing.Point(13, 94);
            this.btnShell.Name = "btnShell";
            this.btnShell.Size = new System.Drawing.Size(97, 30);
            this.btnShell.TabIndex = 1;
            this.btnShell.Text = "Shell Sort";
            this.btnShell.UseVisualStyleBackColor = false;
            this.btnShell.Click += new System.EventHandler(this.btnShell_Click);
            // 
            // btnHeap
            // 
            this.btnHeap.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btnHeap.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnHeap.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHeap.ForeColor = System.Drawing.Color.Black;
            this.btnHeap.Image = ((System.Drawing.Image)(resources.GetObject("btnHeap.Image")));
            this.btnHeap.Location = new System.Drawing.Point(13, 43);
            this.btnHeap.Name = "btnHeap";
            this.btnHeap.Size = new System.Drawing.Size(97, 30);
            this.btnHeap.TabIndex = 0;
            this.btnHeap.Text = "Heap sort";
            this.btnHeap.UseVisualStyleBackColor = false;
            this.btnHeap.Click += new System.EventHandler(this.btnHeap_Click);
            // 
            // bbtnXuatFile
            // 
            this.bbtnXuatFile.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bbtnXuatFile.BackgroundImage")));
            this.bbtnXuatFile.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bbtnXuatFile.Image = ((System.Drawing.Image)(resources.GetObject("bbtnXuatFile.Image")));
            this.bbtnXuatFile.Location = new System.Drawing.Point(512, 15);
            this.bbtnXuatFile.Name = "bbtnXuatFile";
            this.bbtnXuatFile.Size = new System.Drawing.Size(77, 29);
            this.bbtnXuatFile.TabIndex = 14;
            this.bbtnXuatFile.Text = "Xuất File";
            this.bbtnXuatFile.UseVisualStyleBackColor = true;
            this.bbtnXuatFile.Click += new System.EventHandler(this.btnXuatFile_Click);
            // 
            // btnxuatketqua
            // 
            this.btnxuatketqua.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btnxuatketqua.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnxuatketqua.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnxuatketqua.ForeColor = System.Drawing.Color.Black;
            this.btnxuatketqua.Image = global::demosort.Properties.Resources.Untitled;
            this.btnxuatketqua.Location = new System.Drawing.Point(536, 43);
            this.btnxuatketqua.Name = "btnxuatketqua";
            this.btnxuatketqua.Size = new System.Drawing.Size(44, 129);
            this.btnxuatketqua.TabIndex = 2;
            this.btnxuatketqua.Text = "Xuất\r\n\r\nkết\r\n\r\nquả";
            this.btnxuatketqua.UseVisualStyleBackColor = false;
            this.btnxuatketqua.Click += new System.EventHandler(this.btnxuatketqua_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Monotype Corsiva", 35F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label5.Location = new System.Drawing.Point(212, 28);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(210, 56);
            this.label5.TabIndex = 24;
            this.label5.Text = "Demo Sort";
            // 
            // FormUngDung
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(641, 367);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.MaximizeBox = false;
            this.Name = "FormUngDung";
            this.Text = "FormUngDung";
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Button btnRandum;
        private System.Windows.Forms.TextBox txtSophantu;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtQuicksosanh;
        private System.Windows.Forms.TextBox txtHeapsosanh;
        private System.Windows.Forms.TextBox txtShellhoanvi;
        private System.Windows.Forms.TextBox txtHeaphoanvi;
        private System.Windows.Forms.TextBox txtShellsosanh;
        private System.Windows.Forms.TextBox txtQuicktime;
        private System.Windows.Forms.TextBox txtQuickhoanvi;
        private System.Windows.Forms.TextBox txtShelltime;
        private System.Windows.Forms.TextBox txtHeaptime;
        private System.Windows.Forms.Button btbQuick;
        private System.Windows.Forms.Button btnShell;
        private System.Windows.Forms.Button btnHeap;
        private System.Windows.Forms.Button bbtnXuatFile;
        private System.Windows.Forms.Button btnxuatketqua;
        private System.Windows.Forms.Label label5;
    }
}