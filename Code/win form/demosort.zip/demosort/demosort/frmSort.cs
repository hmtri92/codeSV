﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using System.IO;
using DevExpress.XtraBars;
using DevExpress.UserSkins;
using DevExpress.XtraBars.Helpers;

namespace demosort
{
    public partial class frmSort : Form
    {
        int sophantu = 0, dem = 1;
        int delay = 10;
        bool flagReset = false;
        PictureBox[] LQuanbai;
        Label[] LViTri;

        public frmSort()
        {
            InitializeComponent();
        }

        #region Tạo Dữ liệu

        void dinhvilai(int n)
        {
            try
            {
                if (n == 0)
                    return;
                int x = rbcMenu.Width / 2 - sophantu * 40;
                if (x < 0)
                    return;

                for (int i = 1; i <= n; i++)
                {
                    LQuanbai[i].Location = new Point(x, 270);
                    LViTri[i].Left = x;
                    Application.DoEvents();
                    x += 80;
                }
            }
            catch (System.Exception ex)
            {
            	
            }
        }
        void khoitao(int i, int key)
        {
            // Tạo lá bài mới.
            LQuanbai[i] = new PictureBox();
            LQuanbai[i].Size = new System.Drawing.Size(70, 90);
            LQuanbai[i].SizeMode = PictureBoxSizeMode.CenterImage;
            LQuanbai[i].Location = new Point(picgoc.Left, picgoc.Top);
            LQuanbai[i].Image = img52labai.Images[key];
            LQuanbai[i].Tag = key;  // Lưu giá trị của lá bài.
            LQuanbai[i].Visible = true;
            this.Controls.Add(LQuanbai[i]);

            // Tạo list vị trí
            LViTri[i] = new Label();
            LViTri[i].BackColor = Color.Transparent;
            LViTri[i].Size = new Size(70, 50);
            LViTri[i].TextAlign = ContentAlignment.MiddleCenter;
            LViTri[i].ForeColor = Color.DarkMagenta;
            LViTri[i].Text = "[ " + i.ToString() + " ]";
            LViTri[i].Visible = true;
            LViTri[i].Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));


            // Di chuyển lá bài vào vị trí
            int x;
            //int y = 270;                               // Top của các lá bài
            if (i == 1)
            {
                x = rbcMenu.Width / 2 - sophantu * 40; //left của lá bài 0;

            }
            else
            {
                x = LQuanbai[i - 1].Left + 80;
            }
            int dy = 27; // y/10
            int dx = (x - picgoc.Left) / 10 +1  ;
            while (LQuanbai[i].Top > 270 && LQuanbai[i].Left < x)
            {
                LQuanbai[i].Top -= dy;
                if (picgoc.Left < x)
                {
                    LQuanbai[i].Left += dx;
                }
                else
                {
                    LQuanbai[i].Left -= dx;
                }
                Thread.Sleep(20);
                Application.DoEvents();
            }
            LQuanbai[i].Location = new Point(x, 270);
            Application.DoEvents();

            LViTri[i].Location = new Point(LQuanbai[i].Left, 380);
            this.Controls.Add(LViTri[i]);
        }

        void taorandom()
        {
            label1.Enabled = false;
            label1.Visible = false;
            lblbuocnhay.Enabled = false;
            lblbuocnhay.Visible = false;
            for (int i = 1; i <= sophantu; i++)
            {
                this.Controls.Remove(LQuanbai[i]);
                this.Controls.Remove(LViTri[i]);
            }
            Random ra = new Random();
            sophantu = ra.Next(5, 17);
            LQuanbai = new PictureBox[sophantu + 1];
            LViTri = new Label[sophantu + 1];
            for (int i = 1; i <= sophantu; i++)
            {
                khoitao(i, ra.Next(0, 51));
            }
        }

        private void bbtnRandom_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            btnSophantu.Visibility = DevExpress.XtraBars.BarItemVisibility.OnlyInCustomizing;
            btnNhapphantu.Visibility = DevExpress.XtraBars.BarItemVisibility.OnlyInCustomizing;
            taorandom();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            lblbuocnhay.Visible = false;
            label1.Visible = false;
        }

        private void picgoc_Click(object sender, EventArgs e)
        {
            btnSophantu.Visibility = DevExpress.XtraBars.BarItemVisibility.OnlyInCustomizing;
            btnNhapphantu.Visibility = DevExpress.XtraBars.BarItemVisibility.OnlyInCustomizing;
            taorandom();
        }

        private void frmSort_Resize(object sender, EventArgs e)
        {
            dinhvilai(sophantu);
        }

        private void bbtnNhapTC_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            dem = 1;
            for (int i = 1; i <= sophantu; i++)
            {
                this.Controls.Remove(LQuanbai[i]);
                this.Controls.Remove(LViTri[i]);
            }
            btnNhapphantu.Visibility = DevExpress.XtraBars.BarItemVisibility.Always;
            btnSophantu.Visibility = DevExpress.XtraBars.BarItemVisibility.Always;
        }

        private void btnSophantu_HiddenEditor(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            try
            {
                sophantu = int.Parse(btnSophantu.EditValue.ToString());
                if (sophantu > 15 || sophantu < 5)
                {
                    MessageBox.Show("Số phần tử nhập không đúng, giá trị tử 5 đến 15", "Lỗi",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                LQuanbai = new PictureBox[sophantu + 1];
                LViTri = new Label[sophantu + 1];
            }
            catch (System.Exception ex)
            {
                MessageBox.Show("Số phần tử nhập không đúng", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnNhapphantu_HiddenEditor(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            int giatri = -1;
            try
            {
                giatri = int.Parse(btnNhapphantu.EditValue.ToString());
            }
            catch (System.Exception ex)
            {
                MessageBox.Show("Số phần tử nhập không đúng !", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (giatri > 51 || 0 > giatri)
            {
                MessageBox.Show("Phần tử có giá trị trong khoảng từ 0 đến 51 !", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (dem <= sophantu)
            {
                khoitao(dem++, giatri);
                btnNhapphantu.Equals(true);
            }
            else
            {
                MessageBox.Show("Đã nhập đủ số phần tử !", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        
        private void bbtnNhapFile_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            btnSophantu.Visibility = DevExpress.XtraBars.BarItemVisibility.OnlyInCustomizing;
            btnNhapphantu.Visibility = DevExpress.XtraBars.BarItemVisibility.OnlyInCustomizing;
            for (int i = 1; i <= sophantu; i++)
            {
                this.Controls.Remove(LQuanbai[i]);
                this.Controls.Remove(LViTri[i]);
            }
            OpenFileDialog open = new OpenFileDialog();
            open.Title = "Mở File";
            open.Filter = "File text|*.txt|All File|*.*";
            DialogResult tv = open.ShowDialog();
            if (tv == DialogResult.OK)
            {
                docfile(open.FileName);
            }       
        }
        public void docfile(string fname)
        {
            try
            {
                StreamReader read = new StreamReader(fname);
                sophantu = int.Parse(read.ReadLine());
                if (sophantu <= 15 && sophantu >= 5)
                {
                    string s = read.ReadLine();
                    string[] w = s.Split(' ');
                    LQuanbai = new PictureBox[sophantu + 1];
                    LViTri = new Label[sophantu + 1];
                    //A = new int[n];
                    for (int i = 1; i <= sophantu; i++)
                    {
                        try
                        {
                            int gt = int.Parse(w[i -1].ToString());
                            khoitao(i, gt );
                        }
                        catch
                        {
                            MessageBox.Show("Nhập phần tử không hợp lệ !!", "Lỗi",
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            
                            for (int j = 1; j <= i; j++)
                            {
                                this.Controls.Remove(LQuanbai[j]);
                            }
                            read.Close();
                            return;
                        }
                    }
                }
                else MessageBox.Show("số phần tử >= 5 và  <= 15");
                read.Close();
            }
            catch
            {
                MessageBox.Show("Lỗi đọc File !", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        #endregion

        #region Heap Sort
        private void bbntHeapSort_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            for (int tam = 1; tam <= sophantu; tam++ )
            {
                LViTri[tam].Top += 90; 
            }

            label1.Visible = false;
            lblbuocnhay.Visible = false;
            flagReset = false;
            taoHeap(sophantu/2, sophantu);
            int max = sophantu;
            while (max > 1) 
            {
                if (flagReset == true)
                    return;
                pictemp = LQuanbai[1];
                pictemp.Visible = true;
                this.Controls.Add(pictemp);
                LQuanbai[1].Enabled = false;

                LQuanbai[max].Size = new Size(75, 95);
                LQuanbai[max].BackColor = Color.Black;
                pictemp.Size = new System.Drawing.Size(75, 95);
                pictemp.BackColor = Color.Black;

                dichuyenlen(pictemp, true);
                dichuyenxuong(LQuanbai[max]);
                dichuyentraiphai(pictemp, LQuanbai[max], LQuanbai[max].Left);
                dichuyenxuong(pictemp);
                dichuyenlen(LQuanbai[max], true);

                LQuanbai[1] = LQuanbai[max];
                LQuanbai[max] = pictemp;
                LQuanbai[max].BackColor = Color.Red;
                LQuanbai[1].Size = new System.Drawing.Size(70, 90);

                //Thread.Sleep(100);

                taoHeap(1, --max);
            }
            LQuanbai[1].BackColor = Color.Red;
            LQuanbai[1].Size = new Size(75, 95);

            for (int tam = 1; tam <= sophantu; tam++)
            {
                LViTri[tam].Top -= 90;
            }
            MessageBox.Show("Sắp xếp hoàn tất");
        }

        PictureBox pictemp = new PictureBox();
        void taoHeap(int giatri, int max)   // giatri: vị trí bắt đầu tạo heap; max: tạo heap tới vị trí max.
        {
            if (giatri == max)
                return;
            for (int index = giatri; index > 0; index--)  // Tạo heap từ nơi bắt đầu trở về đầu mảng.
            {
                int i = index;
                // Đổi màu lá bài i
                LQuanbai[i].Size = new Size(75, 95);
                LQuanbai[i].BackColor = Color.Blue;
                                
                int vt, dich = i;
                // Xác định lá bài cần đổi
                try // Trường hợp lá bài vị trí i có i*2 && i*2 + 1
                {
                    vt = ( (int)LQuanbai[i * 2].Tag >  (int)LQuanbai[2 * i + 1].Tag )  ? (i * 2) : (i * 2 + 1);
                }
                catch (System.Exception ex)
                {
                    vt = i * 2;
                }
                if (vt > max)
                    vt = i * 2;
                
                // Tạo lá bài tạm pictemp là lá bài i
                pictemp = LQuanbai[i];
                pictemp.Visible = true;
                this.Controls.Add(pictemp);
                LQuanbai[i].Enabled = false;

                bool lentren = true;
                do
                {
                    if (flagReset == true)
                        return;
                    LQuanbai[vt].Size = new Size(75, 95);
                    LQuanbai[vt].BackColor = Color.Blue;

                    if ((int)pictemp.Tag < (int)LQuanbai[vt].Tag)
                    {
                        // Di chuyển lá bài temp lên 100
                        dichuyenlen(pictemp, lentren);

                        // Di chuyển lá bài vt xuống 100
                        dichuyenxuong(LQuanbai[vt]);

                        int xi = pictemp.Left;
                        int xvt = LQuanbai[vt].Left;

                        // Di chuyển lá bài i qua phải, lá bài vt qua trái
                        dichuyentraiphai(pictemp, LQuanbai[vt], xvt);

                        // Chuyển lá bài vt về vị trí i
                        lentren = true;
                        dichuyenlen(LQuanbai[vt], lentren);

                        // Trả lá bài vt về hình cũ
                        LQuanbai[vt].Size = new Size(70, 90);
                        LQuanbai[vt].Location = new Point(xi, 270);
                        pictemp.Left = xvt;

                        // Thay lá bài i
                        LQuanbai[dich] = LQuanbai[vt];
                        dich = vt;
                        try
                        {
                            vt = (int)LQuanbai[vt * 2].Tag > (int)LQuanbai[2 * vt + 1].Tag ? vt * 2 : vt * 2 + 1;
                        }
                        catch (System.Exception ex)
                        {
                            vt *= 2;
                        }
                    }
                    else
                    {
                        LQuanbai[vt].Size = new Size(70, 90);
                        break;
                    }
                    lentren = false;
                } while (vt <= max);

                dichuyenxuong(pictemp);
                pictemp.Top = 270;
                pictemp.Size = new System.Drawing.Size(70, 90);
                LQuanbai[dich] = pictemp;
            }
        }

        
        #endregion

        #region  Điều khiển

        private void bbtnPause_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            if (bbtnPause.Caption == "Pause")
            {
                bbtnPause.Caption = "Start";
                bbtnPause.LargeImageIndex = 2;
                dung();
            }
            else
            {
                bbtnPause.Caption = "Pause";
                bbtnPause.LargeImageIndex = 1;
            }
        }
        void dung()
        {
            while (bbtnPause.Caption == "Start")
            {
                Thread.Sleep(10);
                Application.DoEvents();
            }
        }

        private void bbtnReset_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            try
            {
                label1.Visible = false;
                label1.Enabled = false;
                lblbuocnhay.Visible = false;
                lblbuocnhay.Enabled = false;
                flagReset = true;
                for (int i = 1; i <= sophantu; i++ )
                {
                    //LQuanbai[i] = null;
                    this.Controls.Remove(LQuanbai[i]);
                    this.Controls.Remove(LViTri[i]);
                }
                this.Controls.Remove(pictemp);

            }
            catch (System.Exception ex)
            {
            	
            }
        }

        private void iExit_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            this.Close();
        }

        private void frmSort_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult kq = MessageBox.Show("Thoát chương trình ?", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
            if (kq == DialogResult.Cancel)
                e.Cancel = true;
        }

        private void barTocDo_EditValueChanged(object sender, EventArgs e)
        {
            delay = 10 - Convert.ToInt32(barTocDo.EditValue);
            //MessageBox.Show(delay.ToString() + " " + barTocDo.EditValue.ToString());
        }
        #endregion

        #region Shell Sort

        private void bbtnShellSort_ItemClick(object sender, ItemClickEventArgs e)
        {
            for (int tam = 1; tam <= sophantu; tam++)
            {
                LViTri[tam].Top += 90;
            }
            flagReset = false;  // Gắn cờ bằng false để cái lá bài di chuyển
            label1.Enabled = true;
            label1.Visible = true;
            lblbuocnhay.Enabled = true;
            lblbuocnhay.Visible = true;

            int buocnhay = sophantu / 2;
            while (buocnhay > 0)
            {
                lblbuocnhay.Text = "K = " + buocnhay.ToString();
                for (int i = buocnhay + 1; i <= sophantu; i++)
                {
                    int j = i;
                    pictemp = LQuanbai[j];

                    // Thay đổi khung hình lá bài
                    LQuanbai[j].Enabled = false;
                    pictemp.Enabled = true;
                    doimaubai(pictemp, Color.Green);
                    this.Controls.Add(pictemp);

                    Thread.Sleep(500);
                    Application.DoEvents();

                    bool t = true;
                    while ((j - buocnhay) >= 1 && j > 0 )
                    {
                        if (flagReset == true)
                        {
                            this.Controls.Remove(pictemp);
                            return;
                        }
                        doimaubai(LQuanbai[j - buocnhay], Color.Green);
                        Thread.Sleep(1000);
                        Application.DoEvents();

                        if ((int)LQuanbai[j - buocnhay].Tag > (int)pictemp.Tag)
                        {
                            pictemp.BackColor = Color.Blue;
                            LQuanbai[j - buocnhay].BackColor = Color.Blue;

                            dichuyenlen(pictemp, t);
                            dichuyenxuong(LQuanbai[j - buocnhay]);

                            int vttrai = LQuanbai[j - buocnhay].Left, vtphai = pictemp.Left;
                            dichuyentraiphai(LQuanbai[j - buocnhay], pictemp, vtphai);

                            // Định vị lại cho nó chắc
                            pictemp.Left = vttrai;
                            LQuanbai[j - buocnhay].Left = vtphai;
                            dichuyenlen(LQuanbai[j - buocnhay], true);
                            LQuanbai[j - buocnhay].Top = 270;

                            // Trả lại khung hình cũ
                            LQuanbai[j - buocnhay].Size = new Size(70, 90);

                            // Gán giá trị lại
                            LQuanbai[j] = LQuanbai[j - buocnhay];
                            j -= buocnhay;
                            t = false;

                            Application.DoEvents();
                        }
                        else
                        {
                            // Trả lại khung hình cũ
                            LQuanbai[j - buocnhay].Size = new Size(70, 90);
                            break;
                        }                        
                    }
                    if (t == false)
                    {
                        dichuyenxuong(pictemp);
                        pictemp.Size = new System.Drawing.Size(70, 90);
                        pictemp.Top = 270;
                    }
                    LQuanbai[j] = pictemp;
                    LQuanbai[j].Size = new Size(70, 90);
                }
                buocnhay /= 2;
            }
            for (int tam = 1; tam <= sophantu; tam++)
            {
                LViTri[tam].Top -= 90;
            }
            MessageBox.Show("Sắp xếp hoàn tất");
        }

        #endregion

        #region Di chuyển
        void doimaubai(PictureBox a, Color c)
        {
            a.Size = new Size(75, 95);
            a.BackColor = c;
        }
        void dichuyenlen(PictureBox a, bool t)
        {
            if (t == true)
            {
                for (int k = 0; k < 10; k++)
                {
                    if (flagReset == true)
                    {
                        return;
                    }
                    a.Top -= 10;
                    Thread.Sleep(delay * 2);
                    Application.DoEvents();
                }
            }
        }
        void dichuyenxuong(PictureBox a)
        {
            for (int k = 0; k < 10; k++)
            {
                if (flagReset == true)
                    return;
                a.Top += 10;
                Thread.Sleep(delay * 2);
                Application.DoEvents();
            }
        }
        void dichuyentraiphai(PictureBox quaphai, PictureBox quatrai, int xvt)
        {
            while (quaphai.Left < xvt)
            {
                if (flagReset == true)
                    return;
                quaphai.Left += 10;
                quatrai.Left -= 10;
                Thread.Sleep(delay);
                Application.DoEvents();
            }
        }
        #endregion

        private void bbtnHuongDan_ItemClick(object sender, ItemClickEventArgs e)
        {
            FormHuongDan frmHuongDan = new FormHuongDan();
            frmHuongDan.Show();
        }

        private void bbtnThongTin_ItemClick(object sender, ItemClickEventArgs e)
        {
            FormThongTin t = new FormThongTin();
            t.Show();
        }

        private void bbtnXuatFile_ItemClick(object sender, ItemClickEventArgs e)
        {
            SaveFileDialog save = new SaveFileDialog();
            save.Title = "Mở File";
            save.Filter = "File text|*.txt|All File|*.*";
            DialogResult tv = save.ShowDialog();
            if (tv == DialogResult.OK)
            {
                xuatFile(save.FileName);
            }     
        }
        void xuatFile(string name)
        {
            StreamWriter sw = new StreamWriter(name);
            sw.WriteLine(sophantu);
            for (int i = 1; i <= sophantu; i++ )
            {
                sw.Write((int)LQuanbai[i].Tag);
                sw.Write(" ");
            }
            sw.Close();

        }

        private void bbtnHeapSort_ItemClick(object sender, ItemClickEventArgs e)
        {
            for (int tam = 1; tam <= sophantu; tam++)
            {
                LViTri[tam].Top += 90;
            }

            label1.Visible = false;
            lblbuocnhay.Visible = false;
            flagReset = false;
            taoHeap(sophantu / 2, sophantu);
            int max = sophantu;
            while (max > 1)
            {
                if (flagReset == true)
                    return;
                pictemp = LQuanbai[1];
                pictemp.Visible = true;
                this.Controls.Add(pictemp);
                LQuanbai[1].Enabled = false;

                LQuanbai[max].Size = new Size(75, 95);
                LQuanbai[max].BackColor = Color.Black;
                pictemp.Size = new System.Drawing.Size(75, 95);
                pictemp.BackColor = Color.Black;

                dichuyenlen(pictemp, true);
                dichuyenxuong(LQuanbai[max]);
                dichuyentraiphai(pictemp, LQuanbai[max], LQuanbai[max].Left);
                dichuyenxuong(pictemp);
                dichuyenlen(LQuanbai[max], true);

                LQuanbai[1] = LQuanbai[max];
                LQuanbai[max] = pictemp;
                LQuanbai[max].BackColor = Color.Red;
                LQuanbai[1].Size = new System.Drawing.Size(70, 90);

                //Thread.Sleep(100);

                taoHeap(1, --max);
            }
        }

        private void bbtnDemoUngdung_ItemClick(object sender, ItemClickEventArgs e)
        {
            FormUngDung f = new FormUngDung();
            f.Show();
        }

    }
}
