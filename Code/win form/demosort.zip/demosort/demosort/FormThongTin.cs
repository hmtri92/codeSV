﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace demosort
{
    public partial class FormThongTin : Form
    {
        public FormThongTin()
        {
            InitializeComponent();
        }
    }
}
