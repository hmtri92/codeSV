﻿
create database Music_db
GO

USE Music_db
GO

create table Genres
(
	ID_Genres INT IDENTITY(1,1) PRIMARY KEY,
	name nvarchar(100) NOT NULL,
	Thap_nien int,
)
GO

CREATE TABLE Songs
(
	id_song int IDENTITY(1,1) PRIMARY KEY,
	name nvarchar(50) NOT NULL,
	singer nvarchar(50),
	artist nvarchar(50),
	id_genres int,
	location nvarchar(1000),

	CONSTRAINT fk_SongGenres FOREIGN KEY (id_genres)
	REFERENCES Genres(id_genres)
)
GO

CREATE FUNCTION [dbo].[fLocDauTiengViet]
(
      @strInput NVARCHAR(4000)
) 
RETURNS NVARCHAR(4000)
AS
Begin
	Set @strInput=rtrim(ltrim(lower(@strInput)))
    IF @strInput IS NULL RETURN @strInput
    IF @strInput = '' RETURN @strInput
    Declare @text nvarchar(50), @i int
    Set @text='-''`~!@#$%^&*()?><:|}{,./\"''='';–'
    Select @i= PATINDEX('%['+@text+']%',@strInput ) 
    while @i > 0
        begin
	        set @strInput = replace(@strInput, substring(@strInput, @i, 1), '')
	        set @i = patindex('%['+@text+']%', @strInput)
        End
        Set @strInput =replace(@strInput,'  ',' ')
        
    DECLARE @RT NVARCHAR(4000)
    DECLARE @SIGN_CHARS NCHAR(136)
    DECLARE @UNSIGN_CHARS NCHAR (136)
    SET @SIGN_CHARS = N'ăâđêôơưàảãạáằẳẵặắầẩẫậấèẻẽẹéềểễệế
                  ìỉĩịíòỏõọóồổỗộốờởỡợớùủũụúừửữựứỳỷỹỵý'
                  +NCHAR(272)+ NCHAR(208)
    SET @UNSIGN_CHARS = N'aadeoouaaaaaaaaaaaaaaaeeeeeeeeee
                  iiiiiooooooooooooooouuuuuuuuuuyyyyy'
    DECLARE @COUNTER int
    DECLARE @COUNTER1 int
    SET @COUNTER = 1
    WHILE (@COUNTER <=LEN(@strInput))
    BEGIN   
      SET @COUNTER1 = 1
       WHILE (@COUNTER1 <=LEN(@SIGN_CHARS)+1)
       BEGIN
     IF UNICODE(SUBSTRING(@SIGN_CHARS, @COUNTER1,1)) 
            = UNICODE(SUBSTRING(@strInput,@COUNTER ,1) )
     BEGIN           
          IF @COUNTER=1
              SET @strInput = SUBSTRING(@UNSIGN_CHARS, @COUNTER1,1) 
              + SUBSTRING(@strInput, @COUNTER+1,LEN(@strInput)-1)                   
          ELSE
              SET @strInput = SUBSTRING(@strInput, 1, @COUNTER-1) 
              +SUBSTRING(@UNSIGN_CHARS, @COUNTER1,1) 
              + SUBSTRING(@strInput, @COUNTER+1,LEN(@strInput)- @COUNTER)
              BREAK
               END
             SET @COUNTER1 = @COUNTER1 +1
       END
       SET @COUNTER = @COUNTER +1
    End
 SET @strInput = replace(@strInput,' ','-')
    RETURN lower(@strInput)
End
