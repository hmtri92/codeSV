﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SearchMusics
{
    public partial class frmMedia : Form
    {
        String link;

        public frmMedia(String link)
        {
            this.link = link;
            InitializeComponent();
        }

        private void frmMedia_Load(object sender, EventArgs e)
        {
            axWindowsMediaPlayer1.URL = link;
        }

        public void play(String url)
        {
            axWindowsMediaPlayer1.URL = url;
        }

        public void setURL(string url)
        {
            this.link = url;
        }
    }
}
