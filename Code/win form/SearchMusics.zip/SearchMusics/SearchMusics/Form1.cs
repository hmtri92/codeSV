﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SearchMusics.DB;
using System.Text.RegularExpressions;

namespace SearchMusics
{
    public partial class Form1 : Form
    {
        Music_dbDataContext dataContext;
        frmMedia media;

        public Form1()
        {
            InitializeComponent();

            dataContext = new Music_dbDataContext();
            lblMessage.Text = "";
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            String txtValue = txtSearch.Text;
            search(txtValue);
        }

        private void txtSearch_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                String txtValue = txtSearch.Text;
                search(txtValue);
                txtSearch.Text = txtValue;
            }
        }

        private void btnClear_MouseHover(object sender, EventArgs e)
        {
            toolTip.Show("Clear data", this.btnClear);
        }

        private void btnSearch_MouseHover(object sender, EventArgs e)
        {
            toolTip.Show("Search", this.btnSearch);
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            gridResultSearch.Rows.Clear();
            gridResultSearch.Refresh();
            lblMessage.Text = "";
        }

        private string ConvertToUnSign(string text)
        {
            for (int i = 33; i < 48; i++)
            {
                text = text.Replace(((char)i).ToString(), "");
            }

            for (int i = 58; i < 65; i++)
            {
                text = text.Replace(((char)i).ToString(), "");
            }

            for (int i = 91; i < 97; i++)
            {
                text = text.Replace(((char)i).ToString(), "");
            }

            for (int i = 123; i < 127; i++)
            {
                text = text.Replace(((char)i).ToString(), "");
            }

            //text = text.Replace(" ", "-"); //Comment lại để không đưa khoảng trắng thành ký tự -

            Regex regex = new Regex(@"\p{IsCombiningDiacriticalMarks}+");

            string strFormD = text.Normalize(System.Text.NormalizationForm.FormD);

            return regex.Replace(strFormD, String.Empty).Replace('\u0111', 'd').Replace('\u0110', 'D');
        }

        private void search(String txtValue)
        {
            if (txtValue.Length > 0)
            {
                String searchValue = ConvertToUnSign(txtValue).ToLower();

                try
                {
                    var result = from item in dataContext.Songs
                                 where dataContext.fLocDauTiengViet(item.name).Contains(searchValue)
                                    || dataContext.fLocDauTiengViet(item.singer).Contains(searchValue)
                                    || dataContext.fLocDauTiengViet(item.artist).Contains(searchValue)
                                 select new
                                 {
                                     id = item.id_song,
                                     name = item.name,
                                     singer = item.singer,
                                     artist = item.artist,
                                     genres = item.Genre.name,
                                     location = item.location
                                 };

                    gridResultSearch.DataSource = result;

                    if (result.Count() > 0)
                    {
                        lblMessage.Text = "Kết quả tìm kiếm: \"" + txtValue + "\"";
                    }
                    else
                    {
                        lblMessage.Text = "Không kết quả tìm kiếm: \"" + txtValue + "\"";
                    }
                }
                catch (Exception e)
                {
                    MessageBox.Show("Kiểm tra kết nối với database.", "Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void gridResultSearch_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {

            try
            {
                string location = gridResultSearch.Rows[gridResultSearch.CurrentRow.Index].Cells["colLocation"].Value.ToString();
                FormCollection fc = Application.OpenForms;

                foreach (Form frm in fc)
                {
                    if (frm is frmMedia) {
                        ((frmMedia)frm).play(location);
                        return;
                    }
                }

                media = new frmMedia(location);
                media.Show();
            }
            catch (Exception ex) { }
        }
    }
}
