﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DeTai
{
    public partial class UC_grid : UserControl
    {
        private int numpage = 0;
        object data = null;

        public UC_grid()
        {
            InitializeComponent();
        }

        private void gridMain_DoubleClick(object sender, EventArgs e)
        {

        }

        private void btnRe_Click(object sender, EventArgs e)
        {

        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            
        }

        private void UC_grid_Load(object sender, EventArgs e)
        {
            this.gridMain.DataSource = data;
        }

        public void setData(object data)
        {
            this.data = data;
        }

        public void load()
        {
            UC_grid_Load(null, null);
        }
    }
}
