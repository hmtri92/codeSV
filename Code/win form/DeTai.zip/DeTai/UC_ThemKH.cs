﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DeTai
{
    public partial class UC_ThemKH : UserControl, IController
    {
        KhachHang khachhang;
        SCXMdbDataContext db = new SCXMdbDataContext();

        public UC_ThemKH()
        {
            InitializeComponent();
        }

        public UC_ThemKH(string id)
        {
            InitializeComponent();
            khachhang = db.KhachHangs.Single(p => p.MaKH == id);
        }

        public void save()
        {
            if (!checkData())
                return;

            SCXMdbDataContext db = new SCXMdbDataContext();
            KhachHang khachhang = new KhachHang();

            khachhang.TenKH = txtFullName.Text;
            khachhang.SoDienThoai = txtPhoneNum.Text;
            khachhang.DiaChi = txtAddress.Text;
            khachhang.MaKH = txtPhoneNum.Text;

            db.KhachHangs.InsertOnSubmit(khachhang);
            db.SubmitChanges();
        }

        private bool checkData()
        {
            Color color = Color.Khaki;
            bool result = true;

            Check check = new Check();

            result = check.checkEmpty(txtFullName) && result;
            result = check.checkEmpty(txtAddress) && result;
            result = check.checkPhone(txtPhoneNum) && result;
            
            return result;
        }

        private void textbox_Click(object sender, EventArgs e)
        {
            ((Control)sender).BackColor = Color.White;
        }

        public void Dispose()
        {
            txtPhoneNum.ResetText();
            txtFullName.ResetText();
            txtAddress.ResetText();
        }

        public void load()
        { }
    }
}
