﻿namespace DeTai
{
    partial class UC_grid
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gridMain = new DevExpress.XtraGrid.GridControl();
            this.gridView = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.btnRe = new DevExpress.XtraEditors.SimpleButton();
            this.btnNext = new DevExpress.XtraEditors.SimpleButton();
            this.txtpage = new DevExpress.XtraEditors.TextEdit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtpage.Properties)).BeginInit();
            this.SuspendLayout();
            // 
            // gridMain
            // 
            this.gridMain.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.gridMain.Location = new System.Drawing.Point(0, 36);
            this.gridMain.MainView = this.gridView;
            this.gridMain.Name = "gridMain";
            this.gridMain.Size = new System.Drawing.Size(909, 601);
            this.gridMain.TabIndex = 0;
            this.gridMain.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView});
            this.gridMain.DoubleClick += new System.EventHandler(this.gridMain_DoubleClick);
            // 
            // gridView
            // 
            this.gridView.GridControl = this.gridMain;
            this.gridView.Name = "gridView";
            // 
            // btnRe
            // 
            this.btnRe.Location = new System.Drawing.Point(21, 7);
            this.btnRe.Name = "btnRe";
            this.btnRe.Size = new System.Drawing.Size(40, 23);
            this.btnRe.TabIndex = 1;
            this.btnRe.Text = "<<";
            this.btnRe.Click += new System.EventHandler(this.btnRe_Click);
            // 
            // btnNext
            // 
            this.btnNext.Location = new System.Drawing.Point(113, 7);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(40, 23);
            this.btnNext.TabIndex = 2;
            this.btnNext.Text = ">>";
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // txtpage
            // 
            this.txtpage.Location = new System.Drawing.Point(67, 10);
            this.txtpage.Name = "txtpage";
            this.txtpage.Size = new System.Drawing.Size(40, 20);
            this.txtpage.TabIndex = 3;
            // 
            // UC_grid
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.txtpage);
            this.Controls.Add(this.btnNext);
            this.Controls.Add(this.btnRe);
            this.Controls.Add(this.gridMain);
            this.Name = "UC_grid";
            this.Size = new System.Drawing.Size(909, 637);
            this.Load += new System.EventHandler(this.UC_grid_Load);
            ((System.ComponentModel.ISupportInitialize)(this.gridMain)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtpage.Properties)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraEditors.SimpleButton btnRe;
        private DevExpress.XtraEditors.SimpleButton btnNext;
        private DevExpress.XtraEditors.TextEdit txtpage;
        public DevExpress.XtraGrid.GridControl gridMain;
        public DevExpress.XtraGrid.Views.Grid.GridView gridView;
    }
}
