﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.XtraEditors;

namespace DeTai
{
    public partial class FormLookKhachHang : DevExpress.XtraEditors.XtraForm
    {
        public bool success = false;
        public KhachHang khachhang;
        public FormLookKhachHang()
        {
            InitializeComponent();
        }
    }
}