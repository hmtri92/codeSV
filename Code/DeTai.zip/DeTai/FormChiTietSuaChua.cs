﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.XtraEditors;

namespace DeTai
{
    public partial class FormChiTietSuaChua : DevExpress.XtraEditors.XtraForm
    {
        UserControl body;

        public FormChiTietSuaChua()
        {
            InitializeComponent();
            //initBody();
        }

        void initBody()
        {
            body = new UC_ChiTietSuaChua();
            splitContainerControlRight.Panel2.Controls.Clear();
            splitContainerControlRight.Panel2.Controls.Add(body);
            body.Dock = DockStyle.Fill;
        }
    }
}