﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using System.Xml;

namespace DeTai
{
    public partial class FormAuthenDelete : DevExpress.XtraEditors.XtraForm
    {
        public String value;
        public FormAuthenDelete()
        {
            InitializeComponent();
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            value = txtValue.Text;
            this.DialogResult = DialogResult.OK;
        }
    }
}