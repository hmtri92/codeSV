﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using DevExpress.Skins;
using DevExpress.LookAndFeel;
using DevExpress.UserSkins;
using DevExpress.XtraGrid.Views.Grid;
using System.Xml;
using DevExpress.XtraGrid.Views.Grid.ViewInfo;
using DevExpress.XtraGrid;


namespace DeTai
{
    public partial class FormKeToan : XtraForm
    {
        UserControl mainComponent;
        int numpage = 1;
        public FormKeToan()
        {
            InitializeComponent();
        }
        
        void setAddOrChange()
        {
            splitContainerControlRight.Panel2.Controls.Clear();
            splitContainerControlRight.Panel2.Controls.Add(mainComponent);
            mainComponent.Dock = DockStyle.Fill;

            btnClear.Enabled = true;
            btnSave.Enabled = true;
        }

        private void setView()
        {
            splitContainerControlRight.Panel2.Controls.Clear();
            splitContainerControlRight.Panel2.Controls.Add(panelMain);
            panelMain.Dock = DockStyle.Fill;

            btnClear.Enabled = false;
            btnSave.Enabled = false;
        }

        private void DoRowDoubleClick(GridView view, Point pt)
        {
            GridHitInfo info = view.CalcHitInfo(pt);

            if (info.InRow || info.InRowCell)
            {
                //GridItem row = view.GetRow(info.RowHandle) as GridItem;
                String id = view.GetRowCellValue(info.RowHandle, "ID").ToString();

                SCXMdbDataContext db = new SCXMdbDataContext();
                try
                {
                    SuaChua suachua = db.SuaChuas.Single(p => p.MaSC == id);

                    mainComponent = new UC_HoaDon(suachua);
                    setAddOrChange();
                }
                catch (Exception ex)
                { }
            }
        }

        private void deleteSuaChua(object sender)
        {
            FormAuthenDelete frmAuthen = new FormAuthenDelete();
            frmAuthen.ShowDialog();

            if (frmAuthen.DialogResult != DialogResult.OK)
                return;

            if (frmAuthen.value != "123")
                return;

            GridView view = sender as GridView;
            int row = view.GetSelectedRows()[0];
            String id = view.GetRowCellValue(row, "ID").ToString();

            SCXMdbDataContext db = new SCXMdbDataContext();
            try
            {
                SuaChua suachua = db.SuaChuas.Single(p => p.MaSC == id);
                suachua.deleted = true;
                db.SubmitChanges();
            }
            catch (Exception ex)
            { }


            view.DeleteRow(row);
        }

        /*===========================================================================================
         * */

        private void FormKeToan_Load(object sender, EventArgs e)
        {
            mainComponent = new UC_HoaDon();
            setAddOrChange();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            IController b = (IController)mainComponent;
            b.save();
        }

        private void btnXemHoaDon_LinkClicked(object sender, DevExpress.XtraNavBar.NavBarLinkEventArgs e)
        {
            setView();

            SCXMdbDataContext db = new SCXMdbDataContext();

            var suachuas = from p in db.SuaChuas
                           where p.deleted == false
                          select new 
                          {
                              ID = p.MaSC,
                              date = p.NgaySC,
                              tinhtrang = p.Tinhtrang,
                              xe = p.Xe_Khach.MaXe,
                              tenkhachhang = p.Xe_Khach.KhachHang.TenKH,
                              maKH = p.Xe_Khach.KhachHang.MaKH
                          };

            if (numpage < 0)
                numpage = 0;

            gridMain.DataSource = suachuas.Skip(numpage * 25 - 25).Take(25);

            grdView.PopulateColumns();

            grdView.Columns["ID"].Caption = "Mã sửa chữa";
            grdView.Columns["date"].Caption = "Ngày sửa chữa";
            grdView.Columns["tinhtrang"].Caption = "Đã sửa xong";
            grdView.Columns["xe"].Caption = "Số xe";
            grdView.Columns["tenkhachhang"].Caption = "Khách hàng";
            grdView.Columns["maKH"].Visible = false;
        }

        private void gridMain_DoubleClick(object sender, EventArgs e)
        {
            GridControl grid = sender as GridControl;

            Point pt = grid.PointToClient(Control.MousePosition);

            GridView view = (GridView)grid.FocusedView;

            DoRowDoubleClick(view, pt);
        }

        

        private void gridMain_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete && e.Modifiers == Keys.Control)
            {
                deleteSuaChua(sender);
            }

        }

        private void txtpage_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
            {
                numpage = int.Parse(txtpage.Text);
                btnXemHoaDon_LinkClicked(null, null);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            deleteSuaChua(grdView);
        }

        private void btnRe_Click(object sender, EventArgs e)
        {
            numpage --;
            txtpage.Text = numpage.ToString();
            btnXemHoaDon_LinkClicked(null, null);
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            numpage ++;
            txtpage.Text = numpage.ToString();
            btnXemHoaDon_LinkClicked(null, null);
        }

    }
}