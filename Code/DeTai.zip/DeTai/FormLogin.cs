﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using System.Xml;
using System.Threading;

namespace DeTai
{
    public partial class FormLogin : DevExpress.XtraEditors.XtraForm
    {
        int dem = 0;

        public FormLogin()
        {
            InitializeComponent();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }


        protected internal void btnLogin_Click(object sender, EventArgs e)
        {
            SCXMdbDataContext db = new SCXMdbDataContext();
            String username = txtUserName.Text;
            String pass = txtPassWord.Text;
            TaiKhoan user = null;

            try
            {
                user = db.TaiKhoans.Single(u => u.UserName == username);
            }
            catch (Exception ex)
            {
                warnning();
                return;
            }
            

            if (user.Password != pass )
            {
                warnning();
                return;
            }

            if (user.MaQuyen == "qadmin")
            {
                Program.thread_Admin.SetApartmentState(ApartmentState.STA);
                Program.thread_Admin.Start();
                this.Close();
            }

            if (user.MaQuyen == "qkho")
            {
                Program.thread_Kho.SetApartmentState(ApartmentState.STA);
                Program.thread_Kho.Start();
                this.Close();
            }

            if (user.MaQuyen == "qketoan")
            {
                Program.thread_KeToan.SetApartmentState(ApartmentState.STA);
                Program.thread_KeToan.Start();
                this.Close();
            }

            if (user.MaQuyen == "qsuachua")
            {
                Program.thread_SuaChua.SetApartmentState(ApartmentState.STA);
                Program.thread_SuaChua.Start();
                this.Close();
            }
        }

        void warnning()
        {
            dem++;

            if (dem >= 5)
            {
                Application.Exit();
            }
            else
            {
                String mess = "Số lần đăng nhập còn lại " + (5 - dem);
                lblMessage.Text = mess;
                lblMessage.Visible = true;
            }


            txtUserName.BackColor = Color.Gold;
            txtPassWord.BackColor = Color.Gold;
        }

        private void txtPassWord_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
            {
                btnLogin_Click(null, null);
            }
        }

        private void txtPassWord_Click(object sender, EventArgs e)
        {
            txtUserName.BackColor = Color.White;
            txtPassWord.BackColor = Color.White;
        }
    }
}