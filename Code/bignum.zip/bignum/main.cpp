#include "bignum.h"
#include <stdio.h>
#include <conio.h>

void xuly(bignum a, bignum b);

void main()
{
	cout << "Nhap tinh giai thua: ";
	bignum gt;
	cin >> gt;
	cout <<gt <<"! = ";

	bignum n = giaithua(gt);
	cout <<n <<endl;
	cout << "So chu so: " << n.lastdigit << endl;
	//docso(n);
	cout<<endl;
	//cout <<sizeof(long double);

	bignum a, b, c;
	/*a = 6;
	b = 5;
	c = a%b;*/
	//cout << c;
	int i;
	char ketthuc;

	do 
	{
		cout<<"Nhap a = ";
		cin>>a;
		cout<<"Nhap b = ";
		cin>>b;
		xuly(a, b);
		cout<<"\nNhan Esc de ket thuc\n";
		fflush(stdin);
		ketthuc = getch();
	} while (ketthuc != 27);
}

void xuly(bignum a, bignum b)
{
	int c = 3839;
	bignum d = c;
	cout<<"a + b = "<<(a + b)<<endl;
	cout<<"a - b = "<<(a - b)<<endl;
	cout<<"a * b = "<<(a * b)<<endl;
	cout<<"a / b = "<<(a / b)<<endl;
	cout<<"a mod b = "<<(a % b)<<endl;
	//cout<<"a ^ b = "<<(a ^ b)<<endl;
	//cout<<"a! = "<<(giaithua(a))<<endl;
	cout<<"d = "<<d<<endl;
	cout<<"Doc so a: ";
	docso(a);
	cout<<"\nDoc so b: ";
	docso(b);
	cout<<endl;
}
